use act

select b.cve_banco,b.institucion,count(*) as registros
from ACT as a
inner join [dbo].[act_bancos] as b on a.Banco=b.cve_banco
where [Com Activo]='V'
group by b.cve_banco,b.institucion

use act

select * from act
where [Nombre Grupo Cad] like '%affi%'
--1297

select banco,Afiliacion,Nombre 
into #temp_affinitas
from act
where [Cad Gpo]='999986'

select * from #temp_affinitas
--facturaci�n
select *  
into #temp_sac_affinitas
from
SAC_DIC.dbo.INFO_SAC
where NO_COMERCIO in (select afiliacion from #temp_affinitas)

insert into #temp_sac_affinitas
select *  
from
sac_nov.dbo.INFO_SAC
where NO_COMERCIO in (select afiliacion from #temp_affinitas)

insert into #temp_sac_affinitas
select *  
from
sac_oct.dbo.INFO_SAC
where NO_COMERCIO in (select afiliacion from #temp_affinitas)

insert into #temp_sac_affinitas
select *  
from
sac.dbo.INFO_SAC
where NO_COMERCIO in (select afiliacion from #temp_affinitas)


insert into #temp_sac_affinitas
select *  
from
SAC_ENE.dbo.INFO_SAC
where NO_COMERCIO in (select afiliacion from #temp_affinitas)

select * from #temp_sac_affinitas
--contracargos
select * 
into #temp_cc_affinitas
from [BOS_DB].dbo.[SIA_columnas]
where afiliacion in (select afiliacion from #temp_affinitas)

SELECT * FROM #temp_cc_affinitas

--CC por afiliacion, por codigo de razon, por mes
select 
--a.*,
a.circuito,
a.CR,
a.afiliacion,
ACT.Nombre,
--b.bin,b.ID_INSTITUCION,
b.INSTITUCION as ADQUIRENTE,
--b.MARCA, 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes,
C.INSTITUCION as EMISOR,
COUNT(1) as casos,
SUM(convert(money,A.importe)/100) as total
from BOS_DB.DBO.SIA_columnas AS A 
INNER JOIN BOS_DB.DBO.C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN BOS_DB.DBO.C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
inner join [ACT].[dbo].[ACT]  on A.afiliacion=ACT.Afiliacion
where cc='001' --contracargos no representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND a.nombre IS NOT NULL --elige solo las lineas con casos
AND A.AFILIACION in (select afiliacion from #temp_affinitas)
group by a.circuito,
a.CR,
a.afiliacion,
ACT.Nombre,
b.INSTITUCION,
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))),
C.INSTITUCION
order by casos desc


--CC por afiliacion, por codigo de razon, por mes
select 
--a.*,
a.circuito,
a.CR,
a.afiliacion,
ACT.Nombre,
--b.bin,b.ID_INSTITUCION,
b.INSTITUCION as ADQUIRENTE,
--b.MARCA, 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes,
C.INSTITUCION as EMISOR,
COUNT(1) as casos,
SUM(convert(money,A.importe)/100) as total
from BOS_DB.DBO.SIA_columnas AS A 
INNER JOIN BOS_DB.DBO.C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN BOS_DB.DBO.C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
inner join [ACT].[dbo].[ACT]  on A.afiliacion=ACT.Afiliacion
where cc='001' --contracargos no representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND a.nombre IS NOT NULL --elige solo las lineas con casos
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) in (11,12)
and b.INSTITUCION='AUTOFIN PR'
--AND A.AFILIACION in ('8536602','8537354','8576434')
group by a.circuito,
a.CR,
a.afiliacion,
ACT.Nombre,
b.INSTITUCION,
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))),
C.INSTITUCION
order by casos desc

drop table #temp_affinitas
drop table #temp_cc_affinitas
drop table #temp_sac_affinitas



use act

select * from act 
where Afiliacion in ('8536602','8537354','8576434')

select * from act where 
Nombre like '%parque plaza%'

select * from act_bancos

--8915091

select * from act
where Afiliacion=8915091

select * from act
where banco='P128'
and [Cad Gpo]=1

select Afiliacion,Nombre,institucion as adquirente from act as a
inner join act_bancos as b on a.Banco=b.cve_banco
where [Cad Gpo]=1
and banco not in ('BCMR','BNMX')
and [Com Activo]='V'


select * from act as a
inner join act_bancos as b on a.Banco=b.cve_banco
where [Cad Gpo]=1
and banco not in ('BCMR','BNMX')
and [Com Activo]='V'


--afiliaciones con dos o m�s adquirentes

--septiembre
select 
b.nombre_banco_grupo as Banco,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as cliente,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.tipo_comercio) as tipo_comercio,
a.no_comercio as afiliacion,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.nombre) as nombre_comercial,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.rfc) as rfc--,
--a.FECHA,
--a.cve_txn,
--sum(a.[cantidad]) as txns,
--sum(a.[IMPORTE]) as total
into #temp_final
from sac.dbo.INFO_SAC as a
inner join adquirentes as b on a.id_adquirente =b.id_adquirente
left join act.[dbo].[ACT] as c on a.no_comercio=c.afiliacion
--where a.fecha<='20220906'
group by b.nombre_banco_grupo,c.Afiliacion,c.clasif,a.no_comercio,c.tipo_comercio,c.rfc,c.Nombre

--octubre
--insert into #temp_final
select 
b.nombre_banco_grupo as Banco,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as cliente,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.tipo_comercio) as tipo_comercio,
a.no_comercio as afiliacion,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.nombre) as nombre_comercial,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.rfc) as rfc--,
--a.FECHA,
--a.cve_txn,
--sum(a.[cantidad]) as txns,
--sum(a.[IMPORTE]) as total
into #temp_final
from sac_oct.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join act.[dbo].[ACT] as c on a.no_comercio=c.afiliacion
--where a.fecha<='20220906'
group by b.nombre_banco_grupo,c.Afiliacion,c.clasif,a.no_comercio,c.tipo_comercio,c.rfc,c.Nombre
--select * from #temp_final
--order by afiliacion


--noviembre
--insert into #temp_final
select 
b.nombre_banco_grupo as Banco,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as cliente,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.tipo_comercio) as tipo_comercio,
a.no_comercio as afiliacion,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.nombre) as nombre_comercial,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.rfc) as rfc--,
--a.FECHA,
--a.cve_txn,
--sum(a.[cantidad]) as txns,
--sum(a.[IMPORTE]) as total
into #temp_final
from sac_nov.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join act.[dbo].[ACT] as c on a.no_comercio=c.afiliacion
--where a.fecha<='20220906'
group by b.nombre_banco_grupo,c.Afiliacion,c.clasif,a.no_comercio,c.tipo_comercio,c.rfc,c.Nombre


--diciembre
--insert into #temp_final
select 
b.nombre_banco_grupo as Banco,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as cliente,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.tipo_comercio) as tipo_comercio,
a.no_comercio as afiliacion,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.nombre) as nombre_comercial,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.rfc) as rfc--,
--a.FECHA,
--a.cve_txn,
--sum(a.[cantidad]) as txns,
--sum(a.[IMPORTE]) as total
into #temp_final
from sac_dic.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join act.[dbo].[ACT] as c on a.no_comercio=c.afiliacion
--where a.fecha<='20220906'
group by b.nombre_banco_grupo,c.Afiliacion,c.clasif,a.no_comercio,c.tipo_comercio,c.rfc,c.Nombre


select * from #temp_final
order by afiliacion

select afiliacion, count(1)
from #temp_final
group by afiliacion
having count(1)>1
--drop table #temp_final


select * from INFO_SAC
where NO_COMERCIO in (
8466785,
8538992,
8473920,
8732749,
8474730,
8277085,
7787605,
8531292,
8229139,
8723820,
8844275,
8525092,
8619412,
8524754,
8711787
)
order by no_comercio,fecha, id_adquirente



select * from CIERRE_CERO
where TIPO_MOV='Primer CC'
and AUT is null



select * from CIERRE_CERO
where TIPO_MOV='Representacion'
and AUT is null

select * from CIERRE_CERO
where TIPO_MOV='Segundo CC'
and AUT is null



--tarjeta, referencia, afiliacion m�s de 3 veces
select tarjeta, referencia, afiliacion, COUNT(1) as veces_repetido
from CIERRE_CERO
group by TARJETA,REFERENCIA,AFILIACION
having count(1)>3

select * from CIERRE_CERO
where AFILIACION is null

select * from CIERRE_CERO
where TIPO_MOV not in ('Primer CC','Representacion','Segundo CC')
/****** Script for SelectTopNRows command from SSMS  ******/
insert into [dbo].[C_BINES_EMISOR]
SELECT  [BIN]
      --,[RANGO]
      ,["ID INSTITUCIÃ“N"]
      ,replace([INSTITUCIÃ“N],'"','')
      ,replace([PRODUCTO],'"','')
      ,replace([NATURALEZA],'Ã‰','E')
      ,replace([MARCA],'"','')
      ,["TARJETA CHIP"]
      ,["BIN VIRTUAL"]
      ,["AC MANUAL"]
      ,["AC TPV"]
      ,["AC CASHBACK"]
      ,["AC ATMS"]
      ,["AC ECOMMERCE"]
      ,["AC CARGOS PERIÃ“DICOS"]
      ,["AC VENTAS X TELÃ‰FONO"]
      ,["AC SUCURSAL"]
      ,["AC PAGOS EN EL INTERCAMBIO"]
      ,["AC 3D SECURE"]
      ,[NFC]
      ,[MST]
      ,[WALLET]
      ,["PAN DIN"]
      ,["CVV CVC DIN"]
      ,[NIP]
      ,[TOKENIZACIÃ“N]
      ,[VALE]
      ,["FECHA DE ALTA"]
      ,[PROCESADOR]
  FROM [BOS_DB].[dbo].[Bin_Manager_Anexo_1C]
  where bIN not in (select bin from [dbo].[C_BINES_EMISOR])

  /****** Script for SelectTopNRows command from SSMS  ******/
insert into [dbo].[C_BINES_EMISOR]
SELECT  [BIN]
      --,[RANGO]
      ,["ID INSTITUCIÃ“N"]
      ,replace([INSTITUCIÃ“N],'"','')
      ,replace([PRODUCTO],'"','')
      ,replace([NATURALEZA],'Ã‰','E')
      ,replace([MARCA],'"','')
      ,["TARJETA CHIP"]
      ,["BIN VIRTUAL"]
      ,["AC MANUAL"]
      ,["AC TPV"]
      ,["AC CASHBACK"]
      ,["AC ATMS"]
      ,["AC ECOMMERCE"]
      ,["AC CARGOS PERIÃ“DICOS"]
      ,["AC VENTAS X TELÃ‰FONO"]
      ,["AC SUCURSAL"]
      ,["AC PAGOS EN EL INTERCAMBIO"]
      ,["AC 3D SECURE"]
      ,[NFC]
      ,[MST]
      ,[WALLET]
      ,["PAN DIN"]
      ,["CVV CVC DIN"]
      ,[NIP]
      ,[TOKENIZACIÃ“N]
      ,[VALE]
      ,["FECHA DE ALTA"]
      ,[PROCESADOR]
  FROM [BOS_DB].[dbo].[Bin_Manager_Anexo_1]
    where bIN not in (select bin from [dbo].[C_BINES_EMISOR])

	/****** Script for SelectTopNRows command from SSMS  ******/
insert into [C_BINES_ADQUIRENTE]
SELECT [BIN]
      ,["ID INSTITUCIÃ“N"]
      ,replace([INSTITUCIÃ“N],'"','')
      ,[PROCESADOR]
      ,replace([MARCA],'"','')
      ,["FECHA DE ALTA"]
      ,[POS]
      ,[PAGOS]
  FROM [BOS_DB].[dbo].[Bin_Manager_Anexo_9]
  where BIN not in (select BIN from [dbo].[C_BINES_ADQUIRENTE])

insert into [C_BINES_ADQUIRENTE]
  SELECT [BIN]
      ,["ID INSTITUCIÃ“N"]
      ,replace([INSTITUCIÃ“N],'"','')
      ,[PROCESADOR]
      ,replace([MARCA],'"','')
      ,["FECHA DE ALTA"]
      ,[POS]
      ,[PAGOS]
  FROM [BOS_DB].[dbo].[Bin_Manager_Anexo_9P]
  where BIN not in (select BIN from [dbo].[C_BINES_ADQUIRENTE])


  
insert into SAC.dbo.bines_emisor
select left(bin,6) as bin6,INSTITUCION from bos_db.[dbo].[C_BINES_EMISOR]
where left(bin,6) not in (select bin6 from SAC.dbo.bines_emisor)
group by left(bin,6),INSTITUCION

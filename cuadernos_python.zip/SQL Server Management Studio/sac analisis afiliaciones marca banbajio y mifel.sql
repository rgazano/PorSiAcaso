use SAC_ene

--total
select 
case 
when b.bin6 is not null then 'NACIONAL'
else
	case 
		when SUBSTRING(A.PREFIJO,1,1)='4' then 'VISA'
		when SUBSTRING(A.PREFIJO,1,1)='2' then 'MC'
		when SUBSTRING(A.PREFIJO,1,1)='5' then 'MC'
		when SUBSTRING(A.PREFIJO,1,1)='6' then 'MC'
		when SUBSTRING(A.PREFIJO,1,1)='3' then 'AMEX'
		when SUBSTRING(A.PREFIJO,1,1)='7' then 'PRIV INT' 
		ELSE 'NACIONAL' END
	END AS MARCA,
sum(importe) as total
INTO #TEMP
from INFO_SAC as a
left join SAC.dbo.bines_emisor as b on substring(a.PREFIJO,1,6)=b.bin6
where id_adquirente=78
and FECHA<='20230115'
GROUP BY 
b.bin6
,A.PREFIJO


select 
MARCA,SUM(TOTAL) AS TOTAL from #TEMP
GROUP BY 
MARCA
order by total desc

drop table #TEMP


--por afiliacion

select 
no_comercio,
comercio,
fecha,
case 
when b.bin6 is not null then 'NACIONAL'
else
	case 
		when SUBSTRING(A.PREFIJO,1,1)='4' then 'VISA'
		when SUBSTRING(A.PREFIJO,1,1)='2' then 'MC'
		when SUBSTRING(A.PREFIJO,1,1)='5' then 'MC'
		when SUBSTRING(A.PREFIJO,1,1)='6' then 'MC'
		when SUBSTRING(A.PREFIJO,1,1)='3' then 'AMEX'
		when SUBSTRING(A.PREFIJO,1,1)='7' then 'PRIV INT' 
		ELSE 'NACIONAL' END
	END AS MARCA,
sum(importe) as total,
isnull(c.[Nombre Estado],'') as entidad_fed
INTO #TEMP
from INFO_SAC as a
left join SAC.dbo.bines_emisor as b on substring(a.PREFIJO,1,6)=b.bin6
left join ACT.dbo.ACT as c on a.NO_COMERCIO=c.afiliacion
where id_adquirente=25
and FECHA<='20230115'
GROUP BY no_comercio,comercio,
fecha,
b.bin6,A.PREFIJO,c.[Nombre Estado]
--and b.BIN6 is null

select count(1) from terminales.dbo.detalle
where afiliacion in (select no_comercio from #TEMP)

select no_comercio,comercio,fecha,MARCA,entidad_fed,SUM(TOTAL) AS TOTAL from #TEMP
GROUP BY no_comercio,comercio,
fecha,MARCA,entidad_fed
order by no_comercio,fecha

drop table #TEMP


--por afiliacion

select 
no_comercio,
case 
when b.bin6 is not null then 'NACIONAL'
else
	case 
		when SUBSTRING(A.PREFIJO,1,1)='4' then 'VISA'
		when SUBSTRING(A.PREFIJO,1,1)='2' then 'MC'
		when SUBSTRING(A.PREFIJO,1,1)='5' then 'MC'
		when SUBSTRING(A.PREFIJO,1,1)='6' then 'MC'
		when SUBSTRING(A.PREFIJO,1,1)='3' then 'AMEX'
		when SUBSTRING(A.PREFIJO,1,1)='7' then 'PRIV INT' 
		ELSE 'NACIONAL' END
	END AS MARCA,
sum(importe) as total
INTO #TEMP
from INFO_SAC as a
left join SAC.dbo.bines_emisor as b on substring(a.PREFIJO,1,6)=b.bin6
where id_adquirente=78
and FECHA<='20230115'
GROUP BY no_comercio,
--FECHA, 
b.bin6,A.PREFIJO
--and b.BIN6 is null

select no_comercio,MARCA,SUM(TOTAL) AS TOTAL from #TEMP
GROUP BY no_comercio,MARCA
order by total desc, NO_COMERCIO

drop table #TEMP
use bos_db


--select * from sia_todo
--where linea like '21335%'        
SELECT 
     REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', '.'), 1)) AS c1
   , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', '.'), 2)) AS c2
   , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', '.'), 3)) AS c3
    , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', '.'), 4)) AS c4
   , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', '.'), 5)) AS c5
    , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', '.'), 6)) AS c6
   , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', '.'), 7)) AS c7
    , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', '.'), 8)) AS c8
	 , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', '.'), 9)) AS c9
   , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', '.'), 10)) AS c10
    , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', '.'), 11)) AS c11
   , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', '.'), 12)) AS c12
    , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', '.'), 13)) AS c13
   , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', '.'), 14)) AS c14

FROM dbo.sia_todo;
GO


SELECT 
     REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', ''), 1)) AS c1
   , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', ''), 2)) AS c2
   , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', ''), 3)) AS c3
    , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', ''), 4)) AS c4
   , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', ''), 5)) AS c5
    , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', ''), 6)) AS c6
   , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', ''), 7)) AS c7
    , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', ''), 8)) AS c8
	 , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', ''), 9)) AS c9
   , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', ''), 10)) AS c10
    , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', ''), 11)) AS c11
   , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', ''), 12)) AS c12
    , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', ''), 13)) AS c13
   , REVERSE(PARSENAME(REPLACE(REVERSE(linea), '*', ''), 14)) AS c14

FROM dbo.sia_todo;
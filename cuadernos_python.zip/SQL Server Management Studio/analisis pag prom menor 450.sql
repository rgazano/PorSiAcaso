use SAC_ENE


select * 
into #temp_sac
from INFO_SAC
where cantidad=1


--solo con una transacci�n por fecha
select 
b.nombre_banco_grupo,
NO_COMERCIO,
sum(cantidad) as txns, 
sum(importe) as total, 
sum(importe)/sum(cantidad) as pagare_promedio
into #temp_menores
from #temp_sac  as a 
inner join sac.dbo.Adquirentes as b on a.id_adquirente=b.id_adquirente
where IMPORTE<=450
group by  b.nombre_banco_grupo, NO_COMERCIO-- order by fecha


select 
b.nombre_banco_grupo,
NO_COMERCIO,
sum(cantidad) as txns, 
sum(importe) as total, 
sum(importe)/sum(cantidad) as pagare_promedio
into #temp_mayores
from #temp_sac  as a 
inner join sac.dbo.Adquirentes as b on a.id_adquirente=b.id_adquirente
where IMPORTe>450
group by  b.nombre_banco_grupo, NO_COMERCIO-- order by fecha


select 
isnull(a.nombre_banco_grupo,b.nombre_banco_grupo) as adquirente,
isnull(a.NO_COMERCIO,b.NO_COMERCIO) as afiliacion,
isnull(a.txns,0) as txns_menores,
isnull(a.total,0) as total_menores,
isnull(a.pagare_promedio,0) as pag_prom_menores,
isnull(b.txns,0) as txns_mayores,
isnull(b.total,0) as total_mayores,
isnull(b.pagare_promedio,0) as pag_prom_mayores
 from #temp_menores as a 
full outer join #temp_mayores as b on a.NO_COMERCIO=b.NO_COMERCIO and a.nombre_banco_grupo=b.nombre_banco_grupo


drop table #temp_sac
drop table #temp_mayores
drop table #temp_menores
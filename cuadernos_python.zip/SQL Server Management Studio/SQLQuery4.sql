select C.INSTITUCION,COUNT(*) as cuenta
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
where
 rol=2
and dia2 is not null and A.referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
--and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=1
and dia='22012'
and circuito='BB'
group by c.INSTITUCION
order by cuenta desc

--delete
--from SIA_columnas-- AS A 
--where dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
--and month(convert(date,DATEADD(day, (CAST(RIGHT(dia,3) AS int)-1), CONVERT(datetime,LEFT(dia,2) + '0101', 112))))=1
--and dia='22003'
--and circuito='BB'


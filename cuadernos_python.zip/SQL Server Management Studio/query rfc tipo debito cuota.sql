
select * from act


select rfc,clasif, count(*) as afiliaciones from ACT.dbo.act

where [Tipo Deb]='DC'
--and banco not in ('BCMR','BNMX')
and [Com Activo]='V'
group by rfc,clasif
order by rfc



select rfc,[Razon Social],clasif, count(*) as afiliaciones from ACT.dbo.act
where [Tipo Deb]='DC'
--and banco not in ('BCMR','BNMX')
and [Com Activo]='V'
group by rfc,[Razon Social],clasif
order by rfc
select afiliacion 
into #temp
from act 
where rfc='MJS 0609252B4'
and [Com Activo]='V'


select * from sac_ene.dbo.INFO_SAC
where NO_COMERCIO in (select afiliacion from #temp)


drop table #temp

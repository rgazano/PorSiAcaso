use bos_db


--total
select 
a.rol,
a.circuito,
DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)) as fecha,
A.[id]
      ,A.[circuito]
      ,A.[dia]
      ,A.[dia2]
      ,A.[referencia]
      ,A.[reg]
      ,A.[bin_emisor]
      ,A.[cuenta]
      ,A.[CC]
      ,A.[fecha_tx]
      ,CONVERT(MONEY,A.[importe])/100 AS IMPORTE
      --,A.importe
	  ,A.[CR]
      ,A.[aaa]
      ,A.[fecha_a]
      ,A.[fecha_b]
      ,A.[afiliacion]
      ,A.[nombre],
b.institucion,
B.ID_INSTITUCION,
B.NATURALEZA,
B.MARCA,
SUBSTRING(a.referencia,2,6) as bin_adquirente, 
C.INSTITUCION AS ADQUIRENTE
from SIA_columnas AS A --															493,361
INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN--					493,359			
INNER JOIN [dbo].[C_BINES_ADQUIRENTE] AS C ON SUBSTRING(a.referencia,2,6)=C.BIN--	493,305
where 
cc='001' --contracargos no representaci�n
and dia2 is not null and referencia is not null AND nombre IS NOT NULL
order by id


select 
a.rol,
A.circuito,
convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as fecha,
b.institucion,
COUNT(1) as no_cc,
format(SUM(CONVERT(MONEY,A.[importe])/100),'C') as total
from SIA_columnas AS A --															493,361
INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN--					493,359			
INNER JOIN [dbo].[C_BINES_ADQUIRENTE] AS C ON SUBSTRING(a.referencia,2,6)=C.BIN--	493,305
where 
cc='001' --contracargos no representaci�n
and dia2 is not null and referencia is not null AND nombre IS NOT NULL
group by a.rol,a.circuito,
b.institucion,A.dia
order by fecha


select 
a.rol,
A.circuito,
convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as fecha,
b.institucion,
COUNT(1) as no_cc,
SUM(CONVERT(MONEY,A.[importe])/100) as total
from SIA_columnas AS A --															493,361
INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN--					493,359			
INNER JOIN [dbo].[C_BINES_ADQUIRENTE] AS C ON SUBSTRING(a.referencia,2,6)=C.BIN--	493,305
where 
cc='001' --contracargos no representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND nombre IS NOT NULL
group by a.rol,a.circuito,
b.institucion,A.dia
order by fecha

select 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes, --convierte fecha juliana
A.circuito,
b.institucion,
COUNT(1) as casos,
SUM(convert(money,A.importe)/100) as total
from SIA_columnas AS A 
--INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN --cat�logo de bines, revisar 	
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
where cc='001' --contracargos no representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
group by A.circuito, --agrupado por circuito, mes e instituci�n
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))), 
b.institucion
order by INSTITUCION,mes,a.circuito





select * from C_BINES_ADQUIRENTE
where BIN ='455546'

select a.*,b.bin,b.ID_INSTITUCION,b.INSTITUCION,b.MARCA, convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as fecha
from SIA_columnas AS A 
--INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN --cat�logo de bines, revisar 	
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
where cc='001' --contracargos no representaci�n
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
--and INSTITUCION='BANORTE PR'
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=6


select 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes, --convierte fecha juliana
A.circuito,
b.institucion,
a.CR,
COUNT(1) as casos,
SUM(convert(money,A.importe)/100) as total
from SIA_columnas AS A 
--INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN --cat�logo de bines, revisar 	
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
where cc='001' --contracargos no representaci�n
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
group by A.circuito, --agrupado por circuito, mes e instituci�n
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))), 
b.institucion,A.cr
order by INSTITUCION,mes,a.circuito,casos desc


select 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes, --convierte fecha juliana
A.circuito,
a.CR,
COUNT(1) as casos,
SUM(convert(money,A.importe)/100) as total,
c.[nombre_codigo_razon]
from SIA_columnas AS A 
--INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN --cat�logo de bines, revisar 	
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
inner join [dbo].[BOS_cat_codigos_razon] as C on a.CR=c.id_codigo_razon
where cc='001' --contracargos no representaci�n
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
group by A.circuito, --agrupado por circuito, mes e instituci�n
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))), 
A.cr,c.[nombre_codigo_razon]
order by mes,a.circuito,casos desc


----------------------------------------------
--adquirente por mes, circuito CC's
select 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes, --convierte fecha juliana
A.circuito,
b.institucion,
COUNT(1) as casos,
SUM(convert(money,A.importe)/100) as total
from SIA_columnas AS A 
--INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN --cat�logo de bines, revisar 	
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
where cc='001' --contracargos no representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
group by A.circuito, --agrupado por circuito, mes e instituci�n
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))), 
b.institucion
order by INSTITUCION,mes,a.circuito

--emisor por mes, circuito CC's
select 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes, --convierte fecha juliana
A.circuito,
b.institucion,
COUNT(1) as casos,
SUM(convert(money,A.importe)/100) as total
from SIA_columnas AS A 
INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN --cat�logo de bines, revisar 	
--INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
where cc='001' --contracargos no representaci�n
and a.rol=1
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
group by A.circuito, --agrupado por circuito, mes e instituci�n
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))), 
b.institucion
order by INSTITUCION,mes,a.circuito

--adquirente todo Cc's

select a.*,b.bin,b.ID_INSTITUCION,b.INSTITUCION,b.MARCA, convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as fecha
from SIA_columnas AS A 
--INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN --cat�logo de bines, revisar 	
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
where cc='001' --contracargos no representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
--and INSTITUCION='BANORTE PR'
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=7


--emisor todo CC's

select a.*,b.bin,b.ID_INSTITUCION,b.INSTITUCION,b.MARCA, convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as fecha
from SIA_columnas AS A 
INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN --cat�logo de bines, revisar 	
--INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
where cc='001' --contracargos no representaci�n
and a.rol=1
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
--and INSTITUCION='BANORTE PR'
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=7


--adquirente con emisor todo CC's

select a.*,b.bin,b.ID_INSTITUCION,b.INSTITUCION as ADQUIRENTE,b.MARCA, convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as fecha
,C.BIN as BIN8,C.INSTITUCION as EMISOR
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
where cc='001' --contracargos no representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
--and b.INSTITUCION='BBVA'
and B.INSTITUCION='EVO PAYMENTS MEXICO EG'
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=6
order by EMISOR

--emisor con adquirente todo CC's
select a.*,b.bin,b.ID_INSTITUCION,b.INSTITUCION as ADQUIRENTE,b.MARCA, convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as fecha
,C.BIN as BIN8,C.INSTITUCION as EMISOR
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
where cc='001' --contracargos no representaci�n
and a.rol=1
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
--and b.INSTITUCION='BBVA'
and B.INSTITUCION='EVO PAYMENTS MEXICO EG'
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=6
order by EMISOR

--JULIO todo emisor CL
select 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes,
count(*) as cuenta
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
where cc='001' --contracargos no representaci�n
and a.rol=2
and circuito='BB'
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
--and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=6
group by month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) 

--referencias en 000000, no hace join con bines adquirente 
--bin 53783050 no existe, no hace join con bines emisor 

--JULIO todo adquirente CL
select count(*) as cuenta
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
where cc='001' --contracargos no representaci�n
and a.rol=2
and circuito='CL'
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=6



--JULIO todo adquirente CL
select count(*) as cuenta
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
where cc='001' --contracargos no representaci�n
and a.rol=2
--and circuito='BB'
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=7

--EMISOR CIRCUITO LOCAL JULIO
select a.*,b.bin,b.ID_INSTITUCION,b.INSTITUCION as ADQUIRENTE,b.MARCA, convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as fecha
,C.BIN as BIN8,C.INSTITUCION as EMISOR
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
where cc='001' --contracargos no representaci�n
and a.rol=1
and circuito='CL'
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=7
order by EMISOR


--ADQUIRENTE CIRCUITO LOCAL JULIO
select a.*,b.bin,b.ID_INSTITUCION,b.INSTITUCION as ADQUIRENTE,b.MARCA, convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as fecha
,C.BIN as BIN8,C.INSTITUCION as EMISOR, B.PROCESADOR
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
where cc='001' --contracargos no representaci�n
and a.rol=2
and circuito='BB'
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=7
order by EMISOR

select a.*,b.bin,b.ID_INSTITUCION,b.INSTITUCION as ADQUIRENTE,b.MARCA, convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as fecha
,C.BIN as BIN8,C.INSTITUCION as EMISOR, B.PROCESADOR
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
where cc='001' --contracargos no representaci�n
and a.rol=1
and circuito='BB'
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=7
order by EMISOR


select count(*) as cuenta, convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as dia
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
where 
cc <> '001'--contracargos no representaci�n
and 
a.rol=2
and circuito='CL'
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=7
group by convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))
order by convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))

select 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes,
circuito,
convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as dia,
count(*) as cuenta 
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
where 
--cc <> '001'--contracargos no representaci�n
--and 
a.rol=2
--and circuito='CL'
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
--and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=7
group by month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))),
circuito, convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))
order by 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))),
circuito,convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))

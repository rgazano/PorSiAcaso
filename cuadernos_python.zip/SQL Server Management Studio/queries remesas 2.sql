

--remesa une
--select * from insumo_une

select  --*
a.* 
into #temp1
from insumo_une as a 
inner join [dbo].[ptlf] as b on a.TARJEta=b.[CUENTA] 
and a.IMPORTE=b.importe
and convert(date,a.[FECHA TRANSACCION])=convert(date,b.FECHA)
and convert(int,a.AUTORIZACION)=convert(int,b.aut) 
and b.CR='001'
order by b.importe

select * from #temp1

select --*
a.*
into #temp2
from insumo_une as a 
inner join [dbo].[ptlf] as b on a.TARJEta=b.[CUENTA] 
and a.IMPORTE=b.importe
--and convert(date,a.[FECHA TRANSACCION])=convert(date,b.FECHA)
and convert(int,a.AUTORIZACION)=convert(int,b.aut)
and b.CR='001'
where a.REFERENCIA not in (select REFERENCIA from #temp1)
order by b.importe


select * from #temp2

select *
--a.*
--into #temp3
from insumo_une as a 
inner join [dbo].[ptlf] as b on a.TARJEta=b.[CUENTA] 
--and a.IMPORTE=b.importe
and convert(date,a.[FECHA TRANSACCION])=convert(date,b.FECHA)
and convert(int,a.AUTORIZACION)=convert(int,b.aut)
--and a.COMERCIO=b.COMERCIO
and abs(a.IMPORTE)-abs(b.IMPORTE)>10
and b.CR='001'
where a.REFERENCIA not in (select REFERENCIA from #temp1)
and a.REFERENCIA not in (select REFERENCIA from #temp2)
order by b.importe


select * from #temp3

select --*
a.*
into #temp4
from insumo_une as a 
inner join [dbo].[ptlf] as b on a.TARJEta=b.[CUENTA] 
--and a.IMPORTE=b.importe
--and convert(date,a.[FECHA TRANSACCION])=convert(date,b.FECHA)
--and convert(int,a.AUTORIZACION)=convert(int,b.aut)
where a.REFERENCIA not in (select REFERENCIA from #temp1)
and a.REFERENCIA not in (select REFERENCIA from #temp2)
and a.REFERENCIA not in (select REFERENCIA from #temp3)
order by b.cuenta,b.importe


select distinct(referencia) 
into #temp_ref 
from #temp1

insert into #temp_ref 
select distinct(referencia) from #temp2

insert into #temp_ref 
select distinct(referencia) from #temp3

insert into #temp_ref 
select distinct(referencia) from #temp4

select * from insumo_une
where REFERENCIA not in (select referencia from #temp_ref)


drop table #temp1
drop table #temp2
drop table #temp3
drop table #temp4
drop table #temp_ref 

select * from ptlf
where cuenta in (
'5470968008700906',
'5470968000760004',
'5445480000450060',
'4905669400070770')



select * from insumo_une as a
inner join sicb2 as b on a.TARJETA=b.CUENTA
and a.AUTORIZACION=b.NO_AUT
and a.REFERENCIA=b.NUMERO_REFERENCIA
and a.IMPORTE=b.IMPORTE
where CVE_TXN=1
order by TARJETA,REFERENCIA,a.IMPORTE

select * from insumo_une as a
inner join sicb2 as b on a.TARJETA=b.CUENTA
and a.AUTORIZACION=b.NO_AUT
--and a.REFERENCIA=b.NUMERO_REFERENCIA
--and a.IMPORTE=b.IMPORTE
where CVE_TXN<>1
order by TARJETA,REFERENCIA,a.IMPORTE


select * from insumo_une as a
inner join sicb2 as b on a.TARJETA=b.CUENTA
--and a.AUTORIZACION<>b.NO_AUT
--and a.REFERENCIA=b.NUMERO_REFERENCIA
and a.IMPORTE=b.IMPORTE
where CVE_TXN<>1
and REFERENCIA not in (
		select REFERENCIA from insumo_une as a
		inner join sicb2 as b on a.TARJETA=b.CUENTA
		and a.AUTORIZACION=b.NO_AUT
		--and a.REFERENCIA=b.NUMERO_REFERENCIA
		--and a.IMPORTE=b.IMPORTE
		where CVE_TXN<>1)
order by TARJETA,REFERENCIA,a.IMPORTE
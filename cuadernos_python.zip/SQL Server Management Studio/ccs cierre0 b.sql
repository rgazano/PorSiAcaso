/****** Script for SelectTopNRows command from SSMS  ******/
SELECT  REFERENCIA,AFILIACION, comercio, FECHA_COMP as fecha_representacion
into #temp1
from [dbo].[CIERRE_CERO]
where TIPO_MOV='Representacion'
--and MONTH(FECHA_COMP)=7
order by FECHA_COMP 
--233804


SELECT  a.REFERENCIA,a.AFILIACION,a.COMERCIO, a.fecha_representacion, b.FECHA_COMP as fecha_primer_cc
into #temp2
from #temp1 as a
left outer join [CIERRE_CERO] as b on a.REFERENCIA=b.REFERENCIA and b.TIPO_MOV='Primer CC'
order by fecha_primer_cc 
--233877


--select a.REFERENCIA,a.AFILIACION,a.COMERCIO, a.fecha_primer_cc, a.fecha_representacion,b.FECHA_COMP as fecha_segundo_cc
--into #temp3
--from #temp2 as a
--left outer join [CIERRE_CERO] as b on a.REFERENCIA=b.REFERENCIA and b.TIPO_MOV='Segundo CC'
--order by fecha_primer_cc 

select * from #temp2
where fecha_representacion is not null and fecha_primer_cc is null

drop table #temp1
drop table #temp2
--drop table #temp3
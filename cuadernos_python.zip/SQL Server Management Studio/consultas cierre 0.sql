--Consultas contenidas en Cierre 0

--UPDATE CIERRE_CERO SET FECHA_CONT = #30/06/2022#
--WHERE REMESA = 124
--AND TIPO_MOV IN( 'Representacion')
--AND TIPO = 'NACIONAL';

--DELETE *
--FROM CIERRE_CERO
--WHERE REMESA = [];

--consulta folios
SELECT *
FROM CIERRE_CERO
WHERE FECHA_TX IS NULL;

--consulta_folios_refcont
SELECT *
FROM CIERRE_CERO
WHERE FOLIO_UNICO In ('1736255','1781061','3249448','3783586','7036859','7069441','7088126','7212435','7242306','7267472','7332760','7386883','7477373','7506779','7509709','7539844','7634928','7642338','7671549','7739819','7790322','7911135','7964850','7980190','8012134','8094562','8115235','8197292','8224232','8239721','8261264','8265321','8312053','8503097','8558230','8609733','8692763','8836934','8912263','9005240','9160185','9793225')
ORDER BY 2;

--sql_1cc
--se necesita cambiar a nvarchar(max) la columna tipo_mov
--select *
SELECT [REMESA]
      ,[TIPO]
      ,[FOLIO_UNICO]
      ,[TARJETA]
      ,[REFERENCIA]
      ,[COMERCIO]
      ,[AFILIACION]
      ,[FECHA_TX]
      ,[DIVISA]
      ,[EMISOR]
      ,[RZ]
      ,[CONDICION]
      ,[IMPORTE_DLLS]
      ,[IMPORTE_PESOS]
      ,[IMPORTE_TX]
      ,[DIF_CAM]
      ,[FECHA_CC]
      ,[FECHA_COMP]
      ,[FECHA_CONT]
      ,[TIPO_MOV]
      ,[AUT]
      ,[TRAD_DIRECTO]
      ,[PEM_EMISOR]
      ,[ICE]
      ,[CREDITO_DEBITO]
      ,[Q2]
      ,[C4_S12]
--into #sql_1cc
FROM CIERRE_CERO
--WHERE TIPO_MOV = 'Primer CC'
WHERE TIPO_MOV = 'Primer CC'
ORDER BY REMESA;


--sql_2cc
--select *
SELECT [REMESA]
      ,[TIPO]
      ,[FOLIO_UNICO]
      ,[TARJETA]
      ,[REFERENCIA]
      ,[COMERCIO]
      ,[AFILIACION]
      ,[FECHA_TX]
      ,[DIVISA]
      ,[EMISOR]
      ,[RZ]
      ,[CONDICION]
      ,[IMPORTE_DLLS]
      ,[IMPORTE_PESOS]
      ,[IMPORTE_TX]
      ,[DIF_CAM]
      ,[FECHA_CC]
      ,[FECHA_COMP]
      ,[FECHA_CONT]
      ,convert(varchar(max),TIPO_MOV) as [TIPO_MOV]
      ,[AUT]
      ,[TRAD_DIRECTO]
      ,[PEM_EMISOR]
      ,[ICE]
      ,[CREDITO_DEBITO]
      ,[Q2]
      ,[C4_S12]
into #sql_2cc
FROM CIERRE_CERO
--WHERE TIPO_MOV = 'Segundo CC'
WHERE convert(varchar(max),TIPO_MOV) = 'Segundo CC'
ORDER BY REMESA;

--sql_foliop
SELECT FOLIO_UNICO, [AUT], TIPO_MOV
FROM CIERRE_CERO
WHERE [AUT] Is Not Null;

--sql_repres
--select *
SELECT [REMESA]
      ,[TIPO]
      ,[FOLIO_UNICO]
      ,[TARJETA]
      ,[REFERENCIA]
      ,[COMERCIO]
      ,[AFILIACION]
      ,[FECHA_TX]
      ,[DIVISA]
      ,[EMISOR]
      ,[RZ]
      ,[CONDICION]
      ,[IMPORTE_DLLS]
      ,[IMPORTE_PESOS]
      ,[IMPORTE_TX]
      ,[DIF_CAM]
      ,[FECHA_CC]
      ,[FECHA_COMP]
      ,[FECHA_CONT]
      ,convert(varchar(max),TIPO_MOV) as [TIPO_MOV]
      ,[AUT]
      ,[TRAD_DIRECTO]
      ,[PEM_EMISOR]
      ,[ICE]
      ,[CREDITO_DEBITO]
      ,[Q2]
      ,[C4_S12]
into #sql_repres
FROM CIERRE_CERO
--WHERE TIPO_MOV IN( 'Representacion', 'Prearbitraje')
WHERE convert(varchar(max),TIPO_MOV)  IN ( 'Representacion', 'Prearbitraje')
ORDER BY REMESA;

--sql_repres_fechasdif
--SELECT REMESA, FOLIO_UNICO, DateDiff('d',FECHA_CC,FECHA_CONT)
SELECT REMESA, FOLIO_UNICO, FECHA_CC,FECHA_CONT
--,DateDiff(d,convert(date,FECHA_CC),convert(date,right(FECHA_CONT,10)))
FROM CIERRE_CERO
--WHERE TIPO_MOV IN( 'Representacion') AND  TIPO = 'NACIONAL' AND REMESA >= 120
WHERE convert(varchar(max),TIPO_MOV)= 'Representacion' AND  TIPO = 'NACIONAL' AND REMESA >= 120
ORDER BY REMESA;

--sql_rz_10_11_prearbitraje
SELECT *
FROM CIERRE_CERO
--WHERE TIPO_MOV In ('Representacion','Prearbitraje') And TIPO='INTERNACIONAL' And RZ In ('10.1','10.2','10.3','10.4','11.3')
WHERE convert(varchar(max),TIPO_MOV) In ('Representacion','Prearbitraje') And TIPO='INTERNACIONAL' And RZ In ('10.1','10.2','10.3','10.4','11.3')
ORDER BY REMESA;

--sql_rz_12_13_repres
SELECT *
FROM CIERRE_CERO
--WHERE TIPO_MOV In ('Representacion','Prearbitraje') And TIPO='INTERNACIONAL' And RZ In ('12.1','12.2','12.3','12.4','12.5','12.6','12.7','13.1','13.2','13.3','13.4','13.5','13.6','13.7')
WHERE convert(varchar(max),TIPO_MOV) In ('Representacion','Prearbitraje') And TIPO='INTERNACIONAL' And RZ In ('12.1','12.2','12.3','12.4','12.5','12.6','12.7','13.1','13.2','13.3','13.4','13.5','13.6','13.7')
ORDER BY REMESA;

--sql_totales_x_remesa
--SELECT REMESA, TIPO, TIPO_MOV, COUNT(REMESA) AS TOTALTX
SELECT REMESA, TIPO, convert(varchar(max),TIPO_MOV) as TIPO_MOV, COUNT(REMESA) AS TOTALTX
FROM CIERRE_CERO
GROUP BY REMESA, TIPO, convert(varchar(max),TIPO_MOV)
ORDER BY REMESA, TIPO;

--sql_1cc_repres_2cc
--SELECT DISTINCT A.REMESA, A.FOLIO_UNICO AS FOLIO_1CC, A.TARJETA, A.REFERENCIA, A.TIPO_MOV, B.FOLIO_UNICO AS FOLIO_REPRE, B.TIPO_MOV, 
--B.FECHA_CONT AS FECHA_REPRE, C.FOLIO_UNICO AS FOLIO_2CC, C.TIPO_MOV
--FROM (SQL_1CC AS A RIGHT JOIN SQL_Repres AS B ON (A.REFERENCIA = B.REFERENCIA) AND (A.TARJETA = B.TARJETA)) 
--LEFT JOIN SQL_2CC AS C ON (B.REFERENCIA = C.REFERENCIA) AND (B.TARJETA = C.TARJETA)
--ORDER BY A.REMESA;


SELECT DISTINCT A.REMESA, A.FOLIO_UNICO AS FOLIO_1CC, A.TARJETA, A.REFERENCIA, A.TIPO_MOV, B.FOLIO_UNICO AS FOLIO_REPRE, B.TIPO_MOV, 
B.FECHA_CONT AS FECHA_REPRE, C.FOLIO_UNICO AS FOLIO_2CC, C.TIPO_MOV
FROM #sql_1cc AS A RIGHT JOIN #sql_repres AS B ON (A.REFERENCIA = B.REFERENCIA) AND (A.TARJETA = B.TARJETA)
LEFT JOIN #sql_2cc AS C ON (B.REFERENCIA = C.REFERENCIA) AND (B.TARJETA = C.TARJETA)
ORDER BY A.REMESA;


drop table #sql_1cc
drop table #sql_2cc
drop table #sql_repres
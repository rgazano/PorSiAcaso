use BOS_DB
--consulta por dia

select *
--delete
from SIA_columnas-- AS A 
where 
rol=2
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
--and month(convert(date,DATEADD(day, (CAST(RIGHT(dia,3) AS int)-1), CONVERT(datetime,LEFT(dia,2) + '0101', 112))))=1
and convert(date,DATEADD(day, (CAST(RIGHT(dia,3) AS int)-1), CONVERT(datetime,LEFT(dia,2) + '0101', 112)))='20220420'
--and dia='22003'
and circuito='BB'
order by referencia

-- agrupado por dia, mes, circuito, numero de casos
select 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes,
circuito,
convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as dia,
count(*) as cuenta 
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
where 
--cc <> '001'--contracargos no representaci�n
--and 
a.rol=2
--and circuito='CL'
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
--and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=7
group by month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))),
circuito, convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))
order by 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))),
circuito,convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))


--adquirente por mes, circuito CC's
select 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes, --convierte fecha juliana
A.circuito,
b.institucion,
COUNT(1) as casos,
SUM(convert(money,A.importe)/100) as total
from SIA_columnas AS A 
--INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN --cat�logo de bines, revisar 	
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
where cc='001' --contracargos no representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
group by A.circuito, --agrupado por circuito, mes e instituci�n
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))), 
b.institucion
order by INSTITUCION,mes,a.circuito



--adquirente por mes, circuito REP's
select 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes, --convierte fecha juliana
A.circuito,
b.institucion,
COUNT(1) as casos,
SUM(convert(money,A.importe)/100) as total
from SIA_columnas AS A 
--INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN --cat�logo de bines, revisar 	
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
where cc='002' --contracargos no representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
group by A.circuito, --agrupado por circuito, mes e instituci�n
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))), 
b.institucion
order by INSTITUCION,mes,a.circuito


--emisor por mes, circuito CC's
select 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes, --convierte fecha juliana
A.circuito,
b.institucion,
COUNT(1) as casos,
SUM(convert(money,A.importe)/100) as total
from SIA_columnas AS A 
INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN --cat�logo de bines, revisar 	
--INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
where cc='001' --contracargos no representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
group by A.circuito, --agrupado por circuito, mes e instituci�n
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))), 
b.institucion
order by INSTITUCION,mes,a.circuito


--emisor por mes, circuito REP's
select 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes, --convierte fecha juliana
A.circuito,
b.institucion,
COUNT(1) as casos,
SUM(convert(money,A.importe)/100) as total
from SIA_columnas AS A 
INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN --cat�logo de bines, revisar 	
--INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
where cc='002' --representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
group by A.circuito, --agrupado por circuito, mes e instituci�n
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))), 
b.institucion
order by INSTITUCION,mes,a.circuito
use BOS_DB

--adquirente con emisor todo CC's por mes 
select a.*,b.bin,b.ID_INSTITUCION,b.INSTITUCION as ADQUIRENTE,b.MARCA, convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as fecha
,C.BIN as BIN8,C.INSTITUCION as EMISOR
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
where cc='001' --contracargos no representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
--and b.INSTITUCION='BBVA'
--and B.INSTITUCION='EVO PAYMENTS MEXICO EG'
and id>=12730061 --inicio de 2023
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=1
order by ADQUIRENTE

--adquirente con emisor todo REPS's -- por mes 
select a.*,b.bin,b.ID_INSTITUCION,b.INSTITUCION as ADQUIRENTE,b.MARCA, convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as fecha
,C.BIN as BIN8,C.INSTITUCION as EMISOR
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
where cc='002' --representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
--and b.INSTITUCION='BBVA'
--and B.INSTITUCION='EVO PAYMENTS MEXICO EG'
and id>=12730061 --inicio de 2023
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=1
order by ADQUIRENTE

--adquirente con emisor
--Detalle CCs
--CC por afiliacion, por codigo de razon, por mes
select 
--a.*,
a.circuito,
a.CR,
a.afiliacion,
ACT.Nombre,
--b.bin,b.ID_INSTITUCION,
b.INSTITUCION as ADQUIRENTE,
--b.MARCA, 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes,
C.INSTITUCION as EMISOR,
COUNT(1) as casos,
SUM(convert(money,A.importe)/100) as total
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
inner join [ACT].[dbo].[ACT]  on A.afiliacion=ACT.Afiliacion
where cc='001' --contracargos no representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND a.nombre IS NOT NULL --elige solo las lineas con casos
--and b.INSTITUCION='BBVA'
--and B.INSTITUCION='EVO PAYMENTS MEXICO EG'
--and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=10
group by a.circuito,
a.CR,
a.afiliacion,
ACT.Nombre,
b.INSTITUCION,
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))),
C.INSTITUCION
order by casos desc


--adquirente con emisor
--Detalle REPs
--REPs por afiliacion, por codigo de razon, por mes
select 
--a.*,
a.circuito,
a.CR,
a.afiliacion,
ACT.Nombre,
--b.bin,b.ID_INSTITUCION,
b.INSTITUCION as ADQUIRENTE,
--b.MARCA, 
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))) as mes,
C.INSTITUCION as EMISOR,
COUNT(1) as casos,
SUM(convert(money,A.importe)/100) as total
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 	
inner join [ACT].[dbo].[ACT]  on A.afiliacion=ACT.Afiliacion
where cc='002' --representaci�n
and a.rol=2
and dia2 is not null and referencia is not null AND a.nombre IS NOT NULL --elige solo las lineas con casos
--and b.INSTITUCION='BBVA'
--and B.INSTITUCION='EVO PAYMENTS MEXICO EG'
--and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=8
group by a.circuito,
a.CR,
a.afiliacion,
ACT.Nombre,
b.INSTITUCION,
month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112)))),
C.INSTITUCION
order by casos desc

--casos de banorte y banregio (banbajio?) que se representan.
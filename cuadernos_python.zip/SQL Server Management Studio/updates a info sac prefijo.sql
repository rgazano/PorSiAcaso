use sac

update INFO_SAC
set PREFIJO=REPLACE(prefijo,',','')

update INFO_SAC
set PREFIJO=REPLACE(prefijo,'E7','')

update INFO_SAC
set PREFIJO=prefijo+'0'
where len(prefijo)=5

update INFO_SAC
set PREFIJO=prefijo+'00'
where len(prefijo)=4

update INFO_SAC
set PREFIJO=prefijo+'000'
where len(prefijo)=3
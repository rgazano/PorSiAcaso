USE [BOS_DB]
GO
insert into [dbo].[BOS_Consolidado]
SELECT [ANALISTA]
      ,convert(int,[No ])
      ,[CUENTA]
      ,[REFERENCIA]
      ,[NOMBRE]
      ,[AFILIAC]

------------------------------------------------------------------------------------------------------------------------
	  --,[FECHA TX]
	  --,REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 2)) +'/'+
   -- REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 1)) +'/'+
   -- REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 3)) as [FECHA TX]

	--,case  when len(REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 1)))=1 then 
	--		'0'+REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 1))
	--		else
	--		REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 1))
	--		end
	--		+'/'+
	--case when len(REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 2)))=1 then
	--		'0'+REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 2))
	--		else
	--		REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 2))
	--		end 
	--		 +'/'+
 --   REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 3)) as [FECHA TX]

		,REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 3))+
		case  when len(REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 2)))=1 then 
			'0'+REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 2))
			else
			REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 2))
			end +
	case when len(REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 1)))=1 then
			'0'+REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 1))
			else
			REVERSE(PARSENAME(REPLACE(REVERSE([FECHA TX]), '/', '.'), 1))
			end  as [FECHA TX]
	
------------------------------------------------------------------------------------------------------------------------
      --,[FECHA REPR]
	   --,REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 2)) +'/'+
    --REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 1)) +'/'+
    --REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 3)) as [FECHA REPR]

	--,case  when len(REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 1)))=1 then 
	--		'0'+REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 1))
	--		else
	--		REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 1))
	--		end
	--		+'/'+
	--case when len(REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 2)))=1 then
	--		'0'+REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 2))
	--		else
	--		REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 2))
	--		end 
	--		 +'/'+
 --   REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 3)) as [FECHA REPR]

	,isnull(REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 3))+
		case  when len(REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 2)))=1 then 
			'0'+REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 2))
			else
			REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 2))
			end +
	case when len(REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 1)))=1 then
			'0'+REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 1))
			else
			REVERSE(PARSENAME(REPLACE(REVERSE([FECHA REPR]), '/', '.'), 1))
			end,'19000101')  as [FECHA REPR]
			
------------------------------------------------------------------------------------------------------------------------
      ,[EMISOR]
	  --,RZ
      ,convert(int,[RZ])
      ,[C]
      ,convert(decimal(18,2),replace([IMPORTE],',',''))
	  --,ISNUMERIC(IMPORTE)
	  --,IMPORTE
 ------------------------------------------------------------------------------------------------------------------------
 --,[FCCGO]
	   --,REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 2)) +'/'+
    --REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 1)) +'/'+
    --REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 3)) as [FCCGO]
	--,case  when len(REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 1)))=1 then 
	--		'0'+REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 1))
	--		else
	--		REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 1))
	--		end
	--		+'/'+
	--case when len(REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 2)))=1 then
	--		'0'+REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 2))
	--		else
	--		REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 2))
	--		end 
	--		 +'/'+
 --   REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 3)) as [FCCGO]

	,REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 3))+
		case  when len(REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 2)))=1 then 
			'0'+REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 2))
			else
			REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 2))
			end +
	case when len(REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 1)))=1 then
			'0'+REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 1))
			else
			REVERSE(PARSENAME(REPLACE(REVERSE([FCCGO]), '/', '.'), 1))
			end  as [FCCGO]
 ------------------------------------------------------------------------------------------------------------------------
 --,convert(int,[FOL  SIA])
	  ,[FOL  SIA]
------------------------------------------------------------------------------------------------------------------------
      --,[Fx CONT ]
	   -- ,REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 2)) +'/'+
    --REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 1)) +'/'+
    --REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 3)) as [Fx CONT ]

	--,case  when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 1)))=1 then 
	--		'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 1))
	--		else
	--		REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 1))
	--		end
	--		+'/'+
	--case when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 2)))=1 then
	--		'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 2))
	--		else
	--		REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 2))
	--		end 
	--		 +'/'+
 --   REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 3)) as [Fx CONT ]

	,REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 3))+
		case  when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 2)))=1 then 
			'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 2))
			else
			REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 2))
			end +
	case when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 1)))=1 then
			'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 1))
			else
			REVERSE(PARSENAME(REPLACE(REVERSE([Fx CONT ]), '/', '.'), 1))
			end  as [Fx CONT ]
------------------------------------------------------------------------------------------------------------------------

      ,[DIAS TRANS ]
	  ------------------------------------------------------------------------------------------------------------------------
      --,[Fx VENC]
	  --,REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 2)) +'/'+
   -- REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 1)) +'/'+
   -- REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 3)) as [Fx VENC]

 --  ,case  when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 1)))=1 then 
	--		'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 1))
	--		else
	--		REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 1))
	--		end
	--		+'/'+
	--case when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 2)))=1 then
	--		'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 2))
	--		else
	--		REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 2))
	--		end 
	--		 +'/'+
 --   REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 3)) as [Fx VENC]

	,REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 3))+
		case  when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 2)))=1 then 
			'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 2))
			else
			REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 2))
			end +
	case when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 1)))=1 then
			'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 1))
			else
			REVERSE(PARSENAME(REPLACE(REVERSE([Fx VENC]), '/', '.'), 1))
			end  as [Fx VENC]
------------------------------------------------------------------------------------------------------------------------

      --,[Fx RECUPER ]
	  --,REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 2)) +'/'+
   -- REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 1)) +'/'+
   -- REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 3)) as [Fx RECUPER ]

 --  ,case  when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 1)))=1 then 
	--		'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 1))
	--		else
	--		REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 1))
	--		end
	--		+'/'+
	--case when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 2)))=1 then
	--		'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 2))
	--		else
	--		REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 2))
	--		end 
	--		 +'/'+
 --   REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 3)) as [Fx RECUPER ]

	,isnull(REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 3))+
		case  when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 2)))=1 then 
			'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 2))
			else
			REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 2))
			end +
	case when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 1)))=1 then
			'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 1))
			else
			REVERSE(PARSENAME(REPLACE(REVERSE([Fx RECUPER ]), '/', '.'), 1))
			end,'19000101')  as [Fx RECUPER ]
------------------------------------------------------------------------------------------------------------------------
      ,[REFERENCIA cont]
      ,[2o CHBK]
      ,[DICTAMEN]
      ,[OBSERVACIONES]
      ,[RM NMAL]
      ,[RM WEB]
      ,[BIN]
      ,[CIRCUITO]
      ,[AUT]
      ,[T D]
      ,[REF PROV BO]
      ,[C D]
      ,[PEM ADQ]
      ,[ICE]
      ,[TERRITORIAL]
      ,[PEM EMISOR]
      ,[Q2]
      ,[GIRO]
      ,[C4_S12]
      ,[IND_COM_ELEC]
      ,[TIPO ]
      ,[XX]
      ,[DICTAMEN2]
----------------------------------------------------------------------
      --,[Fx TRABAJO]
	  --,REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 2)) +'/'+
   -- REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 1)) +'/'+
   -- REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 3)) as [Fx TRABAJO]

 --  ,case  when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 1)))=1 then 
	--		'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 1))
	--		else
	--		REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 1))
	--		end
	--		+'/'+
	--case when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 2)))=1 then
	--		'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 2))
	--		else
	--		REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 2))
	--		end 
	--		 +'/'+
 --   REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 3)) as [Fx TRABAJO]

	,isnull(REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 3))+
		case  when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 2)))=1 then 
			'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 2))
			else
			REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 2))
			end +
	case when len(REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 1)))=1 then
			'0'+REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 1))
			else
			REVERSE(PARSENAME(REPLACE(REVERSE([Fx TRABAJO]), '/', '.'), 1))
			end,'19000101')  as [Fx TRABAJO]
----------------------------------------------------------------------

      ,[Sustento de Representacion]
      ,[EVENTOS]
      ,[VALIDACIONES]
  FROM [dbo].[Archivo 3.- Consolidado Nac 2022 Febrero]

GO



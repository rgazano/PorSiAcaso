use workflow


--ventas de sicb2
select a.*, b.NUMERO_COMERCIO 
into #temp1
from insumo_une_folllow as a --173
inner join sicb2 as b on a.[TARJETA FOLLOW ME]=b.CUENTA
and a.REFERENCIA=b.NUMERO_REFERENCIA
and a.AUTORIZACION=b.NO_AUT
and b.CVE_TXN=1 --importante

--con afiliaci�n vamos a ptlf 
select * 
from
insumo_une_folllow as a 
inner join #temp1 as b on a.[TARJETA FOLLOW ME]=b.[TARJETA FOLLOW ME] and a.AUTORIZACION=b.AUTORIZACION
inner join ptlf as c on a.[TARJETA FOLLOW ME]=c.CUENTA 
and convert(int,b.AUTORIZACION)=convert(int,c.AUT) 
and convert(varchar,b.NUMERO_COMERCIO)=convert(varchar,c.AFILIACION)

select * from ptlf as a inner join --173
#temp1 as b on a.CUENTA=b.CUENTA and a.AUT=b.NO_AUT and a.AFILIACION=b.NUMERO_COMERCIO
and a.CR='001'
and TIPO='0210'

drop table #temp1

use workflow


--ventas de sicb2

select * from insumo_une --2154

select --* --2152
b.CUENTA,b.NO_AUT 
into #temp1
from insumo_une as a 
inner join sicb2 as b on a.TARJETA=b.CUENTA
and a.REFERENCIA=b.NUMERO_REFERENCIA
and b.CVE_TXN=1

--con tarjeta y autorizaci�n voy a ptlf 
select * from ptlf as a inner join  --2161
#temp1 as b on a.CUENTA=b.CUENTA and a.AUT=b.NO_AUT
and a.CR='001'
and TIPO='0210'
order by b.CUENTA,b.NO_AUT

--casos duplicados

--4259829002398727
--4915668418761391
--4931580002966957
--4931580003800015
--4931580007242834
--4931720039539969
--4931730021413495
--4931730023965005
--5470968111575427


select --* --2152
b.CUENTA,b.NO_AUT,b.FECHA_PROCESO_TRANSAC 
into #temp2
from insumo_une as a 
inner join sicb2 as b on a.TARJETA=b.CUENTA
and a.REFERENCIA=b.NUMERO_REFERENCIA
and b.CVE_TXN=1

--con tarjeta y autorizaci�n voy a ptlf 
select * from ptlf as a inner join  --1873
#temp2 as b on a.CUENTA=b.CUENTA and a.AUT=b.NO_AUT and convert(date,a.FECHA)=convert(date,b.FECHA_PROCESO_TRANSAC)
and a.CR='001'
and TIPO='0210'
order by b.CUENTA,b.NO_AUT

drop table #temp2



--------------------banregio.
--remesa 621 regs

select *  --620
from 
insumo_banregio as a
inner join sicb2 as b on a.tarjeta=b.CUENTA and a.referencia=b.NUMERO_REFERENCIA
and b.CVE_TXN=1


select --620
b.CUENTA,b.NO_AUT,b.FECHA_CONSUMO_TRANSAC 
into #temp3
from insumo_banregio as a 
inner join sicb2 as b on a.TARJETA=b.CUENTA
and a.REFERENCIA=b.NUMERO_REFERENCIA
and b.CVE_TXN=1

--con tarjeta y autorizaci�n voy a ptlf --482
select * from ptlf as a inner join  
#temp3 as b on a.CUENTA=b.CUENTA and a.AUT=b.NO_AUT-- and convert(date,a.FECHA)=convert(date,b.FECHA_CONSUMO_TRANSAC)
and a.CR='001'
and TIPO='0210'
order by b.CUENTA,b.NO_AUT

--muchos registros sin n�mero de autorizaci�n

drop table #temp3

select * from ptlf
where AUT is null
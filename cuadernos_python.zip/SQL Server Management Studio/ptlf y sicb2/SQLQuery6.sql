select distinct(NO_AUT) from sicb2
order by no_aut desc
select distinct(AUT) from ptlf
order by AUT desc


--remesa une ?
select * 
from insumo_une_folllow as a --17 registros
inner join [dbo].[ptlf] as b on a.TARJEta=b.[CUENTA] --solo cuenta 2,515 registros
--and a.IMPORTE=b.importe
--and convert(int,a.AUTORIZACION)=convert(int,b.aut)
where a.tarjeta='4905669450754600'
order by b.importe


select * 
from insumo_une as a --2154 registros
inner join [dbo].[ptlf] as b on a.TARJEta=b.[CUENTA] --solo cuenta 2,515 registros
and a.IMPORTE=b.importe
and convert(int,a.AUTORIZACION)=convert(int,b.aut)
--where a.tarjeta='4905660490856646'
order by b.importe


select * from sicb2

select * from insumo_une_folllow
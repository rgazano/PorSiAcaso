use BOS_ACCESS300822

--ALTER TABLE cierre_cero ALTER COLUMN fecha_tx date null 
--ALTER TABLE cierre_cero ALTER COLUMN fecha_cc date null 
--ALTER TABLE cierre_cero ALTER COLUMN fecha_comp date not null
--ALTER TABLE cierre_cero ALTER COLUMN fecha_cont date not null
--ALTER TABLE cierre_cero ALTER COLUMN tipo_mov varchar(max) null

--ALTER TABLE cierre_cinco ALTER COLUMN fecha_tx date null 
--ALTER TABLE cierre_cinco ALTER COLUMN fecha_cc date null 
--ALTER TABLE cierre_cinco ALTER COLUMN fecha_comp date null
--ALTER TABLE cierre_cinco ALTER COLUMN fecha_cont date null

--alter table [dbo].[FOLIOS_PAGARE] alter column [AFILIAC] nvarchar(255) null
--alter table [dbo].[FOLIOS_PAGARE] alter column [FECHA_TX] date null
--alter table [dbo].[FOLIOS_PAGARE] alter column [FCCGO] date null
--alter table [dbo].[FOLIOS_PAGARE] alter column [FECHA_CONT] date null

--alter table [dbo].[CIERRE_21] alter column [FECHA_TX] date null
--alter table CIERRE_21 alter column [IMPORTE_DLLS] money null
--alter table CIERRE_21 alter column [IMPORTE_PESOS] money null
--alter table CIERRE_21 alter column [IMPORTE_TX] money null
--alter table CIERRE_21 alter column [DIF_CAM] money null
--ALTER TABLE CIERRE_21 ALTER COLUMN fecha_cc date null 
--ALTER TABLE CIERRE_21 ALTER COLUMN fecha_comp date null
--ALTER TABLE CIERRE_21 ALTER COLUMN fecha_cont date null
--alter table [dbo].[CIERRE_21] alter column [OBS] varchar(max) null
--alter table [dbo].[CIERRE_21] alter column [AUTORIZACION] varchar(max) null
--alter table [dbo].[CIERRE_21] alter column [OBS_C21] varchar(max) null
--alter table [dbo].[CIERRE_21] alter column [TERMINAL_ID] varchar(max) null

--alter table [dbo].[CIERRE_26] alter column [FECHA_RP_26] date null
--ALTER TABLE [CIERRE_26] ALTER COLUMN [OBS_DICTAMEN] varchar(max) null


--alter table [dbo].[CIERRE_45] alter column [FECHA_RP_26] date null
--ALTER TABLE [CIERRE_45] ALTER COLUMN [OBS_DICTAMEN] varchar(max) null
--exec sp_rename 'CIERRE_45.DICTAMEN_26', 'DICTAMEN_45', 'COLUMN';
--exec sp_rename 'CIERRE_45.FECHA_RP_26', 'FECHA_RP_45', 'COLUMN';
--exec sp_rename 'CIERRE_45.BUENA_FE_26', 'BUENA_FE_45', 'COLUMN';


--ALTER TABLE [dbo].[BUENAS_FE] ALTER COLUMN [FECHA_CGO] date null
--ALTER TABLE [dbo].[BUENAS_FE] ALTER COLUMN [FECHA_VEN] date null
--ALTER TABLE [dbo].[BUENAS_FE] ALTER COLUMN [fecha_solicitud] date null
--ALTER TABLE [dbo].[BUENAS_FE] ALTER COLUMN [fecha_respuesta] date null

--ALTER TABLE [dbo].[CARGO_COMER_PAGARE] ALTER COLUMN [FECHA_APLIC] date null
--ALTER TABLE [dbo].[CARGO_COMER_PAGARE] ALTER COLUMN [FECHA_TX] date null
--ALTER TABLE [dbo].[CARGO_COMER_PAGARE] ALTER COLUMN [CUENTA_CONTABLE] nvarchar(255) null
--update [dbo].[CARGO_COMER_PAGARE] set cuenta_contable='2311011816'


--ALTER TABLE [dbo].[CARGO_COMERCIO] ALTER COLUMN [FECHA_CARGO] date null

--ALTER TABLE [dbo].[EMPLAZAMIENTOS] ALTER COLUMN [FECHA_ENVIO] date null
----ALTER TABLE [dbo].[EMPLAZAMIENTOS] ALTER COLUMN [FECHA_EMISION] date not null --no se pudo







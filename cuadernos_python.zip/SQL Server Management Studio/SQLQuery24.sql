select fecha,[id_adquirente],[cve_txn], sum(cantidad) as txns, sum([IMPORTE]) as total
from info_sac
group by [FECHA],[id_adquirente],[cve_txn]
order by [FECHA],[id_adquirente],[cve_txn]



select fecha,[id_adquirente],[cve_txn], sum(cantidad) as txns, sum([IMPORTE]) as total
from info_sac
group by [FECHA],[id_adquirente],[cve_txn]
order by [FECHA],[id_adquirente],[cve_txn]



--- por id adquirente , normal o agregador

select a.fecha 
,a.id_adquirente
,a.cve_txn
,iif(a.comercio not like '%*%' and b.[SIC]<>5399,'Normal','Agregador') as tipo_comercio
,sum(a.cantidad) as txns
,sum(a.importe) as total
from info_sac as a
inner join [dbo].[ACT] as b on a.[NO_COMERCIO]=b.afiliacion
--where a.comercio like '%*%' or b.[SIC]=5399
group by  a.fecha 
,a.id_adquirente
,a.cve_txn
--,tipo_comercio
,a.comercio
,b.SIC

select a.fecha 
,a.id_adquirente
,a.cve_txn
,iif(a.comercio not like '%*%' and b.[SIC]<>5399,'Normal','Agregador') as tipo_comercio
,a.cantidad
,a.importe
into #temp
from info_sac as a
inner join [dbo].[ACT] as b on a.[NO_COMERCIO]=b.afiliacion


select fecha,id_adquirente,cve_txn,tipo_comercio,
sum(cantidad) as txns,
sum(importe) as total
from #temp
group by  fecha,id_adquirente,cve_txn,tipo_comercio


drop table #temp



--- por grupo y normal o agregador


select a.fecha 
,case a.id_adquirente
	when 7 then 'Banorte'
	when 64 then 'Banorte'
	when 41 then 'Getnet'
	when 48 then 'Getnet'
	when 346 then 'Getnet'
	when 58 then 'Afirme'
	when 79 then 'Banregio'
	when 3 then 'GPTM'
	when 364 then 'GPTM'
	when 25 then 'BanBajio'
	when 27 then 'Inbursa'
	when 85 then 'Azteca'
	when 302 then 'FirstData' 
	when 347 then 'Cibanco'
	when 747 then 'Kushki'
	end as id_adquirente
,a.cve_txn
,iif(a.comercio not like '%*%' and b.[SIC]<>5399,'Normal','Agregador') as tipo_comercio
,a.cantidad
,a.importe
into #temp
from info_sac as a
inner join [dbo].[ACT] as b on a.[NO_COMERCIO]=b.afiliacion


select fecha,id_adquirente,cve_txn,tipo_comercio,
sum(cantidad) as txns,
sum(importe) as total
from #temp
group by  fecha,id_adquirente,cve_txn,tipo_comercio


drop table #temp


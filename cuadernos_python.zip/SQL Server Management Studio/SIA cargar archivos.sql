use BOS_DB
--carga de archivos de SIA
 
IF OBJECT_ID('TEMPDB..#TEMP_FILES') IS NOT NULL DROP TABLE #TEMP_FILES

CREATE TABLE #TEMP_FILES
(
FileName VARCHAR(MAX),
DEPTH VARCHAR(MAX),
[FILE] VARCHAR(MAX)
)
 
INSERT INTO #TEMP_FILES
EXEC master.dbo.xp_DirTree 'C:\Cargas\',1,1
 


DECLARE @FILENAME VARCHAR(MAX),@SQL VARCHAR(MAX)
 
select * from #TEMP_FILES

--IF OBJECT_ID('TEMPDB..#TEMP_RESULTS') IS NOT NULL DROP TABLE #TEMP_RESULTS

--CREATE TABLE #TEMP_RESULTS
--(
--[FECHA] [varchar](50) NULL,
--	[TD_PROSA_ACQ_ENTITY] [varchar](50) NULL,
--	[TTR_NUMERO] [varchar](50) NULL,
--	[CANTIDAD] [varchar](50) NULL,
--	[IMPORTE] [varchar](50) NULL,
--	[CUOTA COMERCIO] [varchar](50) NULL,
--	[IVA CUOTA COMERCIO] [varchar](50) NULL,
--	[CUOTA INTERCAMBIO] [varchar](50) NULL,
--	[IVA CUOTA INTERCAMBIO] [varchar](50) NULL,
--	[PREFIJO] [varchar](50) NULL,
--	[NO_COMERCIO] [varchar](50) NULL,
--	[COMERCIO] [varchar](50) NULL
--)
 
WHILE EXISTS(SELECT * FROM #TEMP_FILES)
BEGIN
   BEGIN TRY
      SET @FILENAME = (SELECT TOP 1 FileName FROM #TEMP_FILES)
      SET @SQL = 'BULK INSERT  BOS_DB.[dbo].[SIA_TODO]
      FROM ''C:\Cargas\' + @FILENAME +'''
      WITH (FIRSTROW = 1, FIELDTERMINATOR = '''', ROWTERMINATOR = ''\n'');'

      PRINT @SQL
      EXEC(@SQL)
   END TRY
   BEGIN CATCH
      PRINT 'Failed processing : ' + @FILENAME
   END CATCH

   DELETE FROM #TEMP_FILES WHERE FileName = @FILENAME
END 

--SELECT * FROM #TEMP_RESULTS

--drop table #TEMP_RESULTS
--select * from SIA_TODO

--delete from sia_todo
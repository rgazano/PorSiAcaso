USE [ACT]
GO


--pasos para actualizar ACT
--1. descargar archivo .DAT
--2 drop and create con este script
--3 importar el archivo cambiando con virgulilla ~ y cambiar el tama�o de dato en el archivo de nombre grupo cadena a 100 y columna 37 a 1000
--4 importar a ACT
--5 ejecutar updates posteriores

/****** Object:  Table [dbo].[ACT]    Script Date: 12/10/2022 11:02:52 ******/
SET ANSI_NULLS ON
GO

drop table [ACT]

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ACT](
	[Banco] [varchar](50) NULL,
	[Afiliacion] [varchar](50) NULL,
	[Cad Cve] [varchar](50) NULL,
	[Nombre Cad] [varchar](50) NULL,
	[Cad Gpo] [varchar](50) NULL,
	[Nombre Grupo Cad] [varchar](100) NULL,
	[Crit Enc] [varchar](50) NULL,
	[Descripcion CritEnc] [varchar](50) NULL,
	[Cve Bloqueo] [varchar](50) NULL,
	[Categoria] [varchar](50) NULL,
	[Cat Deb] [varchar](50) NULL,
	[Tipo Deb] [varchar](50) NULL,
	[Nombre] [varchar](50) NULL,
	[Propietario] [varchar](50) NULL,
	[Razon Social] [varchar](50) NULL,
	[Email] [varchar](50) NULL,
	[RFC] [varchar](50) NULL,
	[Domicilio] [varchar](50) NULL,
	[Colonia] [varchar](50) NULL,
	[CP] [varchar](50) NULL,
	[Lada1] [varchar](50) NULL,
	[Telefono1] [varchar](50) NULL,
	[Lada2] [varchar](50) NULL,
	[Telefono2] [varchar](50) NULL,
	[SIC] [varchar](50) NULL,
	[Descripcion SIC] [varchar](50) NULL,
	[Pob] [varchar](50) NULL,
	[Descripcion Pob] [varchar](50) NULL,
	[Edo] [varchar](50) NULL,
	[Nombre Estado] [varchar](50) NULL,
	[Afil Ant] [varchar](50) NULL,
	[Rec Cve] [varchar](50) NULL,
	[Com Activo] [varchar](50) NULL,
	[Fec Alta] [varchar](50) NULL,
	[Fec Ultmod] [varchar](50) NULL,
	[Usr Ultmod] [varchar](50) NULL,
	[Afil Amex] [varchar](50) NULL,
	[Column 37] [varchar](max) NULL--,
	--[clasif] [varchar](20) NULL,
	--[tipo_comercio] [varchar](20) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO



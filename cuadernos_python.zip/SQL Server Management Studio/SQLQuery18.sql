

--update [SAC_carga]
--set fecha='20220910'
--where fecha='10/09/2022 0:00'


--INSERT INTO [dbo].[INFO_SAC]
--           ([FECHA]
--           ,[id_adquirente]
--           ,[cve_txn]
--           ,[cantidad]
--           ,[IMPORTE]
--           ,[CUOTA_COMERCIO]
--           ,[IVA_CUOTA_COMERCIO]
--           ,[CUOTA_INTERCAMBIO]
--           ,[IVA_CUOTA_INTERCAMBIO]
--           ,[PREFIJO]
--           ,[NO_COMERCIO]
--           ,[COMERCIO])
--			SELECT fecha
--				  ,[TD_PROSA_ACQ_ENTITY]
--				  ,[TTR_NUMERO]
--				  ,replace([CANTIDAD],',','')
--				  ,replace([IMPORTE],',','.')
--				  ,replace([CUOTA COMERCIO],',','.')
--				  ,replace([IVA CUOTA COMERCIO],',','.')
--				  ,replace([CUOTA INTERCAMBIO],',','.')
--				  ,replace([IVA CUOTA INTERCAMBIO],',','.')
--				  ,replace([PREFIJO],',0','')
--				  ,[NO_COMERCIO]
--				  ,[COMERCIO]
--			  FROM [dbo].[SAC_carga]



--insert into [dbo].[SAC_sep22]
--select * from [SAC_carga]


--truncate table [SAC_carga]

/*
select * from [dbo].[Algebra$]
where [Acq Country Name] is null

delete from [dbo].[Algebra$]
where [Acq Country Name] is null

select * from [dbo].AME$
where [Acq Country Name] is null

delete from [dbo].AME$
where [Acq Country Name] is null

select * from [dbo].Banwire$
where [Acq Country Name] is null

delete from [dbo].Banwire$
where [Acq Country Name] is null

select * from [dbo].Conketa$
where [Acq Country Name] is null

delete from [dbo].Conketa$
where [Acq Country Name] is null

select * from [dbo].DLOCAL$
where [Acq Country Name] is null

delete from [dbo].DLOCAL$
where [Acq Country Name] is null

select * from [dbo].NetPay$
where [Acq Country Name] is null

delete from [dbo].NetPay$
where [Acq Country Name] is null

select * from [dbo].Pagocon$
where [Acq Country Name] is null

delete from [dbo].Pagocon$
where [Acq Country Name] is null


*/

/*
insert into [dbo].[MC_Oficial]
select 1,* from [dbo].[Algebra$]

truncate table [dbo].[Algebra$]


insert into [dbo].[MC_Oficial]
select 2,* from [dbo].AME$

truncate table [dbo].AME$


insert into [dbo].[MC_Oficial]
select 3,* from [dbo].Banwire$

truncate table [dbo].Banwire$


insert into [dbo].[MC_Oficial]
select 4,* from [dbo].Conketa$

truncate table [dbo].Conketa$




insert into [dbo].[MC_Oficial]
select 5,* from [dbo].DLOCAL$

truncate table [dbo].DLOCAL$


insert into [dbo].[MC_Oficial]
select 6,* from [dbo].NetPay$

truncate table [dbo].NetPay$


insert into [dbo].[MC_Oficial]
select 7,* from [dbo].Pagocon$

truncate table [dbo].Pagocon$
*/

select * from [dbo].[MC_Oficial]






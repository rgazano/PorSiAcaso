select* from
 [dbo].[Ventas_Cred]

select * from [dbo].[SAC_total]
order by id desc


select fecha, tipo_transaccion,[Afiliacion],[Comercio],
sum(cantidad) as txns,sum(importe) as importe
from [SAC_total]
group by fecha, tipo_transaccion,[Afiliacion],[Comercio]
order by txns desc


select fecha, tipo_transaccion,
sum(cantidad) as txns,sum(importe) as importe
from [SAC_total]
group by fecha, tipo_transaccion
order by fecha desc, tipo_transaccion


--dbcc checkident([SAC_total],reseed)


select fecha, --tipo_transaccion,[Afiliacion],[Comercio],
sum(cantidad) as txns,sum(importe) as importe
from [SAC_total]
where Comercio like 'AMAZON %'
group by fecha--, tipo_transaccion,[Afiliacion],[Comercio]
order by fecha desc
use sac


select distinct(fecha) from [SAC_carga]


--update [SAC_carga]
--set fecha='20220910'
--where fecha='10/09/2022 0:00'

--insert into [dbo].[SAC_sep22]
--select * from [SAC_carga]


--truncate table [SAC_carga]

select distinct([TD_PROSA_ACQ_ENTITY]) from [dbo].[SAC_carga]
where 
[FECHA]='10/09/2022 0:00'
--and [TD_PROSA_ACQ_ENTITY]=364
----and ttr_numero=103
----order by 2

select * from [dbo].[SAC_carga]
use ACT


select * from act


select rfc,clasif, count(*) as comercios from ACT.dbo.act
where [Tipo Deb]='DC'
and banco not in ('BCMR','BNMX')
and [Com Activo]='V'
group by rfc,clasif
order by rfc


select rfc,[Razon Social],clasif, count(*) as comercios from ACT.dbo.act
where [Tipo Deb]='DC'
and banco not in ('BCMR','BNMX')
and [Com Activo]='V'
group by rfc,[Razon Social],clasif
order by rfc
/*
-- primeros contracargos duplicados
select TARJETA,REFERENCIA,AFILIACION,AUT,COUNT(1) as cuenta from CIERRE_CERO
where TIPO_MOV='Primer CC'
group by TARJETA,REFERENCIA,AFILIACION,AUT
having COUNT(1)>1

-- primeros cc con afiliacion nula
select TARJETA,REFERENCIA,AFILIACION,AUT,COUNT(1) as cuenta from CIERRE_CERO
where TIPO_MOV='Primer CC'
group by TARJETA,REFERENCIA,AFILIACION,AUT
having COUNT(1)=1
and AFILIACION is null

-- primeros cc con autorizaci�n nula
select TARJETA,REFERENCIA,AFILIACION,AUT,COUNT(1) as cuenta from CIERRE_CERO
where TIPO_MOV='Primer CC'
group by TARJETA,REFERENCIA,AFILIACION,AUT
having COUNT(1)=1
and aut is null
*/
/*
declare @tabla_foliosBOS table(
folio_BOS int,
[TARJETA] [nvarchar](50) NULL,
[REFERENCIA] [nvarchar](50) NULL,
[AFILIACION] [nvarchar](255) NULL,
[AUT] [nvarchar](255) NULL)

insert into @tabla_foliosBOS
select row_number() over (order by tarjeta) as folio_BOS,TARJETA,REFERENCIA,AFILIACION,AUT from CIERRE_CERO
where TIPO_MOV='Primer CC'
group by TARJETA,REFERENCIA,AFILIACION,AUT
having COUNT(1)=1
and AFILIACION is not null
*/

----creaci�n de nueva tabla de cierre cero

--CREATE TABLE [dbo].[NUEVO_CIERRE_CERO](
--	[folio_BOS] [int] NOT NULL,
--	[TIPO_MOV] [int] NOT NULL,
--	[REMESA] [int] NULL,
--	[TIPO] [nvarchar](255) NULL,
--	[FOLIO_UNICO] [nvarchar](50) NULL,
--	[TARJETA] [nvarchar](50) NULL,
--	[REFERENCIA] [nvarchar](50) NULL,
--	[COMERCIO] [nvarchar](255) NULL,
--	[AFILIACION] [nvarchar](255) NULL,
--	[FECHA_TX] [date] NULL,
--	[DIVISA] [nvarchar](255) NULL,
--	[EMISOR] [nvarchar](255) NULL,
--	[RZ] [nvarchar](255) NULL,
--	[CONDICION] [nvarchar](255) NULL,
--	[IMPORTE_DLLS] [money] NULL,
--	[IMPORTE_PESOS] [money] NULL,
--	[IMPORTE_TX] [money] NULL,
--	[DIF_CAM] [money] NULL,
--	[FECHA_CC] [date] NULL,
--	[FECHA_COMP] [date] NOT NULL,
--	[FECHA_CONT] [date] NOT NULL,
--	[AUT] [nvarchar](255) NULL,
--	[TRAD_DIRECTO] [nvarchar](255) NULL,
--	[PEM_EMISOR] [nvarchar](255) NULL,
--	[ICE] [nvarchar](255) NULL,
--	[CREDITO_DEBITO] [nvarchar](255) NULL,
--	[Q2] [nvarchar](255) NULL,
--	[C4_S12] [nvarchar](255) NULL,
-- CONSTRAINT [PK_NUEVO_CIERRE_CERO] PRIMARY KEY CLUSTERED 
--(
--	[folio_BOS] ASC,
--	[TIPO_MOV] ASC
--)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
--) ON [PRIMARY]
--GO


--insert into [dbo].[NUEVO_CIERRE_CERO]
--SELECT b.folio_BOS
--		,100 as [TIPO_MOV]
--		,A.[REMESA]
--      ,A.[TIPO]
--      ,A.[FOLIO_UNICO]
--      ,A.[TARJETA]
--      ,A.[REFERENCIA]
--      ,A.[COMERCIO]
--      ,A.[AFILIACION]
--      ,A.[FECHA_TX]
--      ,A.[DIVISA]
--      ,A.[EMISOR]
--      ,A.[RZ]
--      ,A.[CONDICION]
--      ,A.[IMPORTE_DLLS]
--      ,A.[IMPORTE_PESOS]
--      ,A.[IMPORTE_TX]
--      ,A.[DIF_CAM]
--      ,A.[FECHA_CC]
--      ,A.[FECHA_COMP]
--      ,A.[FECHA_CONT]
--      --,A.[TIPO_MOV]
--      ,A.[AUT]
--      ,A.[TRAD_DIRECTO]
--      ,A.[PEM_EMISOR]
--      ,A.[ICE]
--      ,A.[CREDITO_DEBITO]
--      ,A.[Q2]
--      ,A.[C4_S12]
--  FROM [BOS_ACCESS300822].[dbo].[CIERRE_CERO] as a
--  inner join @tabla_foliosBOS  as b on a.TARJETA=b.TARJETA and a.REFERENCIA=b.REFERENCIA and a.AFILIACION=b.AFILIACION and a.AUT=b.aut
--  where TIPO_MOV='Primer CC'

select * from [dbo].[NUEVO_CIERRE_CERO]

select folio_BOS,TARJETA,REFERENCIA,AFILIACION,AUT from [NUEVO_CIERRE_CERO]

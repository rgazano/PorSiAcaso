
select left(bin,6) as bin6, INSTITUCION 
into #bines_emisor
from BOS_DB.dbo.C_BINES_EMISOR
where INSTITUCION<>'SI VALE FINTECH'
group by left(bin,6),INSTITUCION
order by bin6, INSTITUCION



--- por grupo y normal o agregador


select a.fecha 
,case a.id_adquirente
	when 7 then 'Banorte'
	when 64 then 'Banorte'
	when 41 then 'Getnet'
	when 48 then 'Getnet'
	when 346 then 'Getnet'
	when 58 then 'Afirme'
	when 79 then 'Banregio'
	when 3 then 'GPTM'
	when 364 then 'GPTM'
	when 25 then 'BanBajio'
	when 27 then 'Inbursa'
	when 85 then 'Azteca'
	when 302 then 'FirstData' 
	when 347 then 'Cibanco'
	when 747 then 'Kushki'
	end as id_adquirente
,a.cve_txn
,iif(a.comercio not like '%*%' and b.[SIC]<>5399,'Normal','Agregador') as tipo_comercio
,a.cantidad
,a.importe
,case when C.bin6 is null then 
		case when left(a.prefijo,1)='2' then 'MC'
			when left(a.prefijo,1)='5' then 'MC'
			when left(a.prefijo,1)='4' then 'Visa'
		else 'Otros' end
	else c.INSTITUCION end as Emisor,
b.SIC as Giro
into #temp
from info_sac as a
inner join [dbo].[ACT] as b on a.[NO_COMERCIO]=b.afiliacion
left join #bines_emisor as C on left(prefijo,6)=C.bin6
--where C.bin6 is null


select fecha,id_adquirente,cve_txn,tipo_comercio,Emisor,Giro,
sum(cantidad) as txns,
sum(importe) as total
from #temp
group by  fecha,id_adquirente,cve_txn,tipo_comercio,Emisor,Giro


drop table #temp
drop table #bines_emisor
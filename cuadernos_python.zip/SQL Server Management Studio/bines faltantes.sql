select *
from SIA_columnas AS A --															428,396
--INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN--					428,394			
--INNER JOIN [dbo].[C_BINES_ADQUIRENTE] AS C ON SUBSTRING(a.referencia,2,6)=C.BIN--	428,351
where 
cc='001' --contracargos no representaci�n
and dia2 is not null and referencia is not null AND nombre IS NOT NULL
order by id

--bin 53783050 no est� en catalogo de bines emisor
select *
from SIA_columnas AS A --															
left JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN
where B.BIN is null
and cc='001' --contracargos no representaci�n
and dia2 is not null and referencia is not null AND nombre IS NOT NULL
order by id

--BIN 458962 no est� en el cat�logo de bines de adquirente
select 
SUBSTRING(a.referencia,2,6) as bin_adquirente
from SIA_columnas AS A --															428,396
INNER JOIN [dbo].C_BINES_EMISOR AS B ON LEFT(A.CUENTA,8)=B.BIN--					428,394			
left JOIN [dbo].[C_BINES_ADQUIRENTE] AS C ON SUBSTRING(a.referencia,2,6)=C.BIN--	428,351
where 
c.bin is null
and cc='001' --contracargos no representaci�n
and dia2 is not null and referencia is not null AND nombre IS NOT NULL
order by id

--INSERT INTO C_BINES_ADQUIRENTE
--SELECT BIN,ID_INSTITUCION,REPLACE(INSTITUCION,'"',''),PROCESADOR,REPLACE(MARCA,'"',''),FECHA_ALTA,POS,PAGOS FROM [dbo].[Bin_Manager_Anexo_9P]
--WHERE BIN NOT IN (SELECT BIN FROM [dbo].[C_BINES_ADQUIRENTE])
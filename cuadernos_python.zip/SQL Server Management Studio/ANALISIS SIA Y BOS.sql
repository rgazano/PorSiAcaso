use BOS_DB


select a.*,
b.bin,b.ID_INSTITUCION,b.INSTITUCION as ADQUIRENTE,b.MARCA, 
convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as fecha
,C.BIN as BIN8,C.INSTITUCION as EMISOR, 
B.PROCESADOR,
d.FOLIO_UNICO
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 
inner join BOS_ACCESS.dbo.CIERRE_CERO AS d ON REPLACE(A.referencia,'-','')=d.REFERENCIA AND A.cuenta=d.TARJETA
where 
--cc='001' --contracargos no representaci�n
--and 
a.rol=1
--and circuito='BB'
and dia2 is not null and A.referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=7
order by EMISOR

use BOS_DB


select a.*,
b.bin,b.ID_INSTITUCION,b.INSTITUCION as ADQUIRENTE,b.MARCA, 
convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))) as fecha
,C.BIN as BIN8,C.INSTITUCION as EMISOR, 
B.PROCESADOR
from SIA_columnas AS A 
INNER JOIN C_BINES_ADQUIRENTE as B on SUBSTRING(a.referencia, 2,6)=B.BIN 
INNER JOIN [dbo].C_BINES_EMISOR AS C ON LEFT(A.CUENTA,8)=C.BIN --cat�logo de bines, revisar 
where 
--cc='001' --contracargos no representaci�n
--and 
a.rol=1
--and circuito='BB'
and dia2 is not null and A.referencia is not null AND nombre IS NOT NULL --elige solo las lineas con casos
and month(convert(date,DATEADD(day, (CAST(RIGHT(a.dia,3) AS int)-1), CONVERT(datetime,LEFT(a.dia,2) + '0101', 112))))=7
AND B.INSTITUCION='BANORTE PR'
order by EMISOR

select distinct [NO_COMERCIO] 
into #temp_sac
from [dbo].[INFO_SAC] 


select [NO_COMERCIO],
	case when b.afiliacion is null then 'No actualizado'
		else b.Banco end as cve_banco,
	case when b.SIC is null then 'No actualizado'
		when b.sic=5399 then 'Agregador'
		when b.Nombre like '%*%' then 'Agregador'
		else 'Normal' end as tipo_comercio,
	'SI' as transaccionando
		into #temp_sac1
from #temp_sac as A
left join [dbo].[ACT] as b on a.[NO_COMERCIO]=b.afiliacion


select a.cve_banco,tipo_comercio,transaccionando,count(*) as conteo, 
case when b.cve_banco is null then 'No actualizado'
		else b.institucion end as institucion
into #SALIDA
		from #temp_sac1 as a
left join [dbo].[act_bancos] as b on a.cve_banco=b.cve_banco
group by a.cve_banco,tipo_comercio,transaccionando,b.institucion,b.cve_banco

--select Banco,count(*) as total_act,
--b.institucion
--from [ACT] as a 
--inner join [dbo].[act_bancos] as b on a.Banco=b.cve_banco
--where [Com Activo]='V'
--and banco not in ('BCMR','BNMX')
--group by banco,b.institucion

select a.[Afiliacion],a.Banco,a.SIC, 
case when a.SIC is null then 'No actualizado'
		when a.sic=5399 then 'Agregador'
		when a.Nombre like '%*%' then 'Agregador'
		else 'Normal' end as tipo_comercio,
		'No' as transaccionando
into #temp_act
from 
[dbo].[ACT] as a
where a.Afiliacion not in (
select [NO_COMERCIO] from #temp_sac)
and [Com Activo]='V'
and banco not in ('BCMR','BNMX')

insert into #SALIDA
select banco,tipo_comercio,transaccionando,count(*) as conteo,
b.institucion
from #temp_act as a
inner join [dbo].[act_bancos] as b on a.banco=b.cve_banco
group by a.banco,tipo_comercio,transaccionando,b.institucion--,b.cve_banco


select * from #SALIDA

drop table #temp_sac
drop table #temp_sac1
drop table #temp_act
drop table #SALIDA
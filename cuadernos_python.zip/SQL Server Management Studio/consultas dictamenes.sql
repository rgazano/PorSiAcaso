--consultas contenidas en bd_dictamenes

--DELETE *
--FROM BUENAS_FE;


--DELETE *
--FROM EMPLAZAMIENTOS;

--sql_consulta_cc
SELECT REF_CONTABLE, REMESA, FECHA_CARGO
FROM CARGO_COMERCIO
WHERE ref_contable = 'DCC5180987673 '
ORDER BY 1;

--sql_remesas_ccomer
SELECT DISTINCT REMESA
FROM CARGO_COMERCIO;



USE Workflow
select * from insumo_banregio


SELECT 
* 
FROM insumo_banregio AS A
inner JOIN [dbo].[sicb2_banregio] AS B 
ON a.Tarjeta=B.CUENTA
AND A.Referencia=B.NUMERO_REFERENCIA
--AND A.Autorizacion=B.NO_AUT
and RIGHT('000000' + Ltrim(Rtrim(A.Autorizacion)),6)=B.NO_AUT
and convert(money,a.Importe)=convert(money,b.IMPORTE)
and b.CVE_TXN=1
ORDER BY CUENTA, Referencia


SELECT 
a.* 
into #caso1
FROM insumo_banregio AS A
inner JOIN [dbo].[sicb2_banregio] AS B 
ON a.Tarjeta=B.CUENTA
AND A.Referencia=B.NUMERO_REFERENCIA
AND A.Autorizacion=B.NO_AUT
and convert(money,a.Importe)=convert(money,b.IMPORTE)
and b.CVE_TXN=1
ORDER BY CUENTA, Referencia

--select * from #caso1

select *
FROM insumo_banregio AS A
inner JOIN [dbo].[sicb2_banregio] AS B 
ON a.Tarjeta=B.CUENTA
AND A.Referencia=B.NUMERO_REFERENCIA
AND A.Autorizacion=B.NO_AUT
--and convert(money,a.Importe)=convert(money,b.IMPORTE)
and b.CVE_TXN=1
and a.Referencia not in (select Referencia from #caso1)

select a.*
into #caso2
FROM insumo_banregio AS A
inner JOIN [dbo].[sicb2_banregio] AS B 
ON a.Tarjeta=B.CUENTA
AND A.Referencia=B.NUMERO_REFERENCIA
AND A.Autorizacion=B.NO_AUT
and b.CVE_TXN=1
and a.Referencia not in (select Referencia from #caso1)


select *
FROM insumo_banregio AS A
inner JOIN [dbo].[sicb2_banregio] AS B 
ON a.Tarjeta=B.CUENTA
AND A.Referencia=B.NUMERO_REFERENCIA
--AND A.Autorizacion=B.NO_AUT
--and convert(money,a.Importe)=convert(money,b.IMPORTE)
and b.CVE_TXN=1
and a.Referencia not in (select Referencia from #caso1)
and a.Referencia not in (select Referencia from #caso2)


select a.*
into #caso3
FROM insumo_banregio AS A
inner JOIN [dbo].[sicb2_banregio] AS B 
ON a.Tarjeta=B.CUENTA
AND A.Referencia=B.NUMERO_REFERENCIA
--AND A.Autorizacion=B.NO_AUT
--and convert(money,a.Importe)=convert(money,b.IMPORTE)
and b.CVE_TXN=1
and a.Referencia not in (select Referencia from #caso1)
and a.Referencia not in (select Referencia from #caso2)


select *
FROM insumo_banregio AS A
inner JOIN [dbo].[sicb2_banregio] AS B 
ON a.Tarjeta=B.CUENTA
--AND A.Referencia=B.NUMERO_REFERENCIA
AND A.Autorizacion=B.NO_AUT
and convert(money,a.Importe)=convert(money,b.IMPORTE)
and b.CVE_TXN=1
and a.Referencia not in (select Referencia from #caso1)
and a.Referencia not in (select Referencia from #caso2)
and a.Referencia not in (select Referencia from #caso3)

drop table #caso1

drop table #caso2

drop table #caso3
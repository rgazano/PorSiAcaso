use SAC_MAR
--Adquirente por dia por cve de transaccion
select 
a.fecha,
b.nombre_banco_grupo,
a.[cve_txn],
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
into #temp_totales
from INFO_SAC_INTERREDES as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
group by a.fecha,
b.nombre_banco_grupo,
a.[cve_txn]

select a.fecha,
a.nombre_banco_grupo,
(select isnull(sum(txns),0)  from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=101) as ventas_credito_txns,
(select isnull(sum(total),0) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=101) as ventas_credito_total,
(select isnull(sum(txns),0)  from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=108) as devs_credito_txns,
(select isnull(sum(total),0) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=108) as devs_credito_total,
(select isnull(sum(txns),0)  from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=103) as ventas_debito_txns,
(select isnull(sum(total),0) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=103) as ventas_debito_total,
(select isnull(sum(txns),0)  from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=109) as devs_debito_txns,
(select isnull(sum(total),0) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=109) as devs_debito_total,
(select isnull(sum(txns),0) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=106) as cashback_txns,
(select isnull(sum(total),0) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=106) as cashback_total,
sum(txns) as txns,
sum(total) as total
from #temp_totales as a
group by a.fecha,a.nombre_banco_grupo

--totales por banco

select 
a.nombre_banco_grupo,
sum(total) as total,
sum(txns) as txns
from #temp_totales as a
group by a.nombre_banco_grupo
order by total desc

drop table #temp_totales
use sac

select 
Banco,
institucion,
afiliacion,
[Nombre],
[SIC] as giro,
[Descripcion SIC] as nombre_giro,
case when [Com Activo] = 'V' then 'Activo' else 'Inactivo' end as Activo,
case when convert(int,SUBSTRING([Fec Alta],7,2))>22 
			then SUBSTRING([Fec Alta],1,6)+'19'+SUBSTRING([Fec Alta],7,2)
		else
			SUBSTRING([Fec Alta],1,6)+'20'+SUBSTRING([Fec Alta],7,2)	end as fecha_alta,
case when convert(int,SUBSTRING([Fec Ultmod],7,2))>22 
			then SUBSTRING([Fec Ultmod],1,6)+'19'+SUBSTRING([Fec Ultmod],7,2)
		else
			SUBSTRING([Fec Ultmod],1,6)+'20'+SUBSTRING([Fec Ultmod],7,2)	end as fecha_mod,
			clasif,
tipo_comercio
from act 
inner join [dbo].[act_bancos] on banco=cve_banco

use SAC_ene

update SAC_ene.dbo.[SAC_carga]
set fecha='20230123'
where fecha='23/01/2023 0:00'


update [SAC_carga]
set PREFIJO=REPLACE(prefijo,',','')

update [SAC_carga]
set PREFIJO=REPLACE(prefijo,'E7','')

update [SAC_carga]
set PREFIJO=prefijo+'0'
where len(prefijo)=5

update [SAC_carga]
set PREFIJO=prefijo+'00'
where len(prefijo)=4

update [SAC_carga]
set PREFIJO=prefijo+'000'
where len(prefijo)=3

/*

INSERT INTO SAC_ene.dbo.[INFO_SAC]
           ([FECHA]
           ,[id_adquirente]
           ,[cve_txn]
           ,[cantidad]
           ,[IMPORTE]
           ,[CUOTA_COMERCIO]
           ,[IVA_CUOTA_COMERCIO]
           ,[CUOTA_INTERCAMBIO]
           ,[IVA_CUOTA_INTERCAMBIO]
           ,[PREFIJO]
           ,[NO_COMERCIO]
           ,[COMERCIO])
			SELECT fecha
				  ,[TD_PROSA_ACQ_ENTITY]
				  ,[TTR_NUMERO]
				  ,replace([CANTIDAD],',','')
				  ,replace([IMPORTE],',','.')
				  ,replace([CUOTA COMERCIO],',','.')
				  ,replace([IVA CUOTA COMERCIO],',','.')
				  ,replace([CUOTA INTERCAMBIO],',','.')
				  ,replace([IVA CUOTA INTERCAMBIO],',','.')
				  ,replace([PREFIJO],',0','')
				  ,[NO_COMERCIO]
				  ,[COMERCIO]
			  FROM SAC_ene.dbo.[SAC_carga]





-- truncate table SAC_ene.dbo.SAC_carga


*/

--delete from INFO_SAC
--where FECHA='20221204'
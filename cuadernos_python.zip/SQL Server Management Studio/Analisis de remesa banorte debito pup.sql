USE Workflow

--SELECT * FROM insumo_banorte_tdd_pup

--SELECT COUNT(*) FROM PTLF

--SELECT COUNT(*) FROM sicb2


SELECT 
* 
FROM insumo_banorte_tdd_pup AS A
inner JOIN sicb2 AS B 
ON A.[Numero de Plastico]=B.CUENTA
AND A.[Numero de Referencia]=B.NUMERO_REFERENCIA
AND A.[Aut Banortel]=B.NO_AUT
and convert(money,a.[Monto de la Transacci�n])=convert(money,b.IMPORTE)
and b.CVE_TXN=1
ORDER BY [Numero de Plastico], [Numero de Referencia]

SELECT 
a.* 
into #caso1
FROM insumo_banorte_tdd_pup AS A
inner JOIN sicb2 AS B 
ON A.[Numero de Plastico]=B.CUENTA
AND A.[Numero de Referencia]=B.NUMERO_REFERENCIA
AND A.[Aut Banortel]=B.NO_AUT
and convert(money,a.[Monto de la Transacci�n])=convert(money,b.IMPORTE)
and b.CVE_TXN=1
ORDER BY [Numero de Plastico], [Numero de Referencia]

--select * from #caso1

select *
from insumo_banorte_tdd_pup as a
inner join sicb2 as B
ON A.[Numero de Plastico]=B.CUENTA
AND A.[Numero de Referencia]=B.NUMERO_REFERENCIA
and a.[Aut Banortel]=b.NO_AUT
and b.CVE_TXN=1
and a.[Numero de Referencia] not in (select [Numero de Referencia] from #caso1)


select a.*
into #caso2
from insumo_banorte_tdd_pup as a
inner join sicb2 as B
ON A.[Numero de Plastico]=B.CUENTA
AND A.[Numero de Referencia]=B.NUMERO_REFERENCIA
and a.[Aut Banortel]=b.NO_AUT
and b.CVE_TXN=1
and a.[Numero de Referencia] not in (select [Numero de Referencia] from #caso1)


select *
from insumo_banorte_tdd_pup as a
inner join sicb2 as B
ON A.[Numero de Plastico]=B.CUENTA
AND A.[Numero de Referencia]=B.NUMERO_REFERENCIA
--and a.[Aut Banortel]=b.NO_AUT
and b.CVE_TXN=1
and a.[Numero de Referencia] not in (select [Numero de Referencia] from #caso1)
and a.[Numero de Referencia] not in (select [Numero de Referencia] from #caso2)
 
 
select a.*
into #caso3
from insumo_banorte_tdd_pup as a
inner join sicb2 as B
ON A.[Numero de Plastico]=B.CUENTA
AND A.[Numero de Referencia]=B.NUMERO_REFERENCIA
--and a.[Aut Banortel]=b.NO_AUT
and b.CVE_TXN=1
and a.[Numero de Referencia] not in (select [Numero de Referencia] from #caso1)
and a.[Numero de Referencia] not in (select [Numero de Referencia] from #caso2)


select *
from insumo_banorte_tdd_pup as a
inner join sicb2 as B
ON A.[Numero de Plastico]=B.CUENTA
and convert(money,a.[Monto de la Transacci�n])=convert(money,b.IMPORTE)
and a.[Aut Banortel]=b.NO_AUT
and b.CVE_TXN=1
and a.[Numero de Referencia] not in (select [Numero de Referencia] from #caso1)
and a.[Numero de Referencia] not in (select [Numero de Referencia] from #caso2)
and a.[Numero de Referencia] not in (select [Numero de Referencia] from #caso3)
--drop table #caso1


select * from ptlf
--where CUENTA='4915669476672470'
where CUENTA='4915669451175424'
order by FECHA


select * from sicb2
--where CUENTA='4915669476672470'
where CUENTA='4915669451175424'

order by FECHA_CONSUMO_TRANSAC


drop table #caso1

drop table #caso2

drop table #caso3
--referencias duplicadas
select REFERENCIA,count(*) as cuenta 
into #temp1
from CIERRE_CERO
group by REFERENCIA
having count(*)>3
order by cuenta desc

-- N�meros de autorizaci�n nulos

--Segundos CC sin Representacion

--comparar n�meos de autorizaci�n como enteros 
--
SELECT  * 
from [dbo].[CIERRE_CERO]
where REFERENCIA not in (select REFERENCIA from #temp1)
order by tarjeta,referencia,afiliacion,remesa,aut

drop table #temp1

USE [BOS_ACCESS]
GO

----referencias duplicadas
--select REFERENCIA,count(*) as cuenta from CIERRE_CERO
--group by REFERENCIA
--having count(*)>1
--order by cuenta desc

----folios unicos duplicados
select FOLIO_UNICO,count(*) as cuenta from CIERRE_CERO
group by FOLIO_UNICO
having count(*)>1
order by cuenta desc

SELECT A.[REMESA]
      ,A.[TIPO]
      ,A.[FOLIO_UNICO]
      ,A.[TARJETA]
      ,A.[REFERENCIA]
	        ,A.[TIPO_MOV]
      ,A.[COMERCIO]
      ,A.[AFILIACION]
      ,A.[FECHA_TX]
      ,A.[DIVISA]
      ,A.[EMISOR]
      ,A.[RZ]
      ,A.[CONDICION]
      ,A.[IMPORTE_DLLS]
      ,A.[IMPORTE_PESOS]
      ,A.[IMPORTE_TX]
      ,A.[DIF_CAM]
      ,A.[FECHA_CC]
      ,A.[FECHA_COMP]
      ,A.[FECHA_CONT]

      ,A.[AUT]
      ,A.[TRAD_DIRECTO]
      ,A.[PEM_EMISOR]
      ,A.[ICE]
      ,A.[CREDITO_DEBITO]
      ,A.[Q2]
      ,A.[C4_S12]
	  from CIERRE_CERO as A
where FOLIO_UNICO='18779754'

--Consulta
SELECT A.[REMESA]
      ,A.[TIPO]
      ,A.[FOLIO_UNICO]
      ,A.[TARJETA]
      ,A.[REFERENCIA]
      ,A.[COMERCIO]
      ,A.[AFILIACION]
      ,A.[FECHA_TX]
      ,A.[DIVISA]
      ,A.[EMISOR]
      ,A.[RZ]
      ,A.[CONDICION]
      ,A.[IMPORTE_DLLS]
      ,A.[IMPORTE_PESOS]
      ,A.[IMPORTE_TX]
      ,A.[DIF_CAM]
      ,A.[FECHA_CC]
      ,A.[FECHA_COMP]
      ,A.[FECHA_CONT]
      ,A.[TIPO_MOV]
      ,A.[AUT]
      ,A.[TRAD_DIRECTO]
      ,A.[PEM_EMISOR]
      ,A.[ICE]
      ,A.[CREDITO_DEBITO]
      ,A.[Q2]
      ,A.[C4_S12]
	  ,B.PREDICTAMEN
	  ,B.OBS
	  --,B.FOLIO_PAGARE
	  ,C.FOLIO_WEB
	  ,C.ESTATUS
	  ,C.OBS_C21
	  ,C.TERMINAL_ID
	  ,C.RM
	  ,D.DICTAMEN_26
	  ,D.OBS_DICTAMEN
	  ,D.FECHA_RP_26
	  ,Dd.DICTAMEN_26 as DICTAMEN_45
	  ,Dd.OBS_DICTAMEN as OBS_DICTAMEN_45
	  ,Dd.FECHA_RP_26 as FECHA_RP_45

	  ,G.FECHA_ENVIO as FECHA_ARBITRAJE
	  ,G.FOLIO AS ROL_CASE
	  ,G.ESTATUS_EMPZ AS FALLO_ARBITRAJE
	  ,G.FECHA_EMISION AS FECHA_FALLO

	  ,gg.FECHA_SOLICITUD
	  ,gg.SEGUNDO_CC
	  ,gg.ESTATUS_BF
	  ,gg.FECHA_RESPUESTA
	  ,gg.IMPORTE_BF
	  ,gg.OBS_BF


	  ,F.FECHA_CARGO
	  ,F.REMESA AS REMESA_CARGO
	  ,F.IMPORTE
	  ,F.CTA_CONTABLE
	  ,F.ESTATUS_REVERSO
	  
	  ,E.FECHA_APLIC
	  ,E.MOTIVO
	  ,E.REMESA AS REMESA_CARGO_P
	  ,E.CUENTA_CONTABLE
	  
	  --,H.OBS1
	  --,H.OBS2
	  --,I.IMPORTE as IMP_QUEBRANTO
  FROM [dbo].[CIERRE_CERO] as A 
  left outer join [dbo].[CIERRE_CINCO] as B on A.FOLIO_UNICO=B.FOLIO_UNICO
  left outer join [dbo].[CIERRE_21] as C on A.FOLIO_UNICO=C.FOLIO_UNICO 
  left outer join [dbo].[CIERRE_26] as D on A.FOLIO_UNICO=D.FOLIO_UNICO 
  LEFT outer join CIERRE_45 as DD on A.FOLIO_UNICO=DD.FOLIO_UNICO 
  left outer join [dbo].[EMPLAZAMIENTOS] as G on A.FOLIO_UNICO=G.REF_CONTABLE 
  --left outer join [dbo].[PREARBITRAJES] as H on A.FOLIO_UNICO=H.REF_CONTABLE 
  LEFT OUTER JOIN [dbo].[BUENAS_FE] AS gg on A.FOLIO_UNICO=GG.REF_CONTABLE 
  left outer join [dbo].[CARGO_COMERCIO] as F on A.FOLIO_UNICO=F.REF_CONTABLE 
	left outer join [dbo].[CARGO_COMER_PAGARE] as E on A.FOLIO_UNICO=E.REF_CONTABLE 
  --left outer join [dbo].[QUEBRANTOS] as I on A.FOLIO_UNICO=I.REF_CONTABLE 
  --WHERE MONTH(A.FECHA_CONT)=5 
  where a.FOLIO_UNICO in ('18779754','18298655','18392582','17756204')
	order by A.FOLIO_UNICO

-- select * from CIERRE_CERO
--where REFERENCIA='74518992068999908343114'
--and TARJETA='4772113001638823'

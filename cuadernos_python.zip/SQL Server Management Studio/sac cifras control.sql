use SAC_ene

select fecha, count(1) as registros, sum(cantidad) as txns, sum(importe) as total, sum(importe)/sum(cantidad) as pagare_promedio
from INFO_SAC
--where id_adquirente=40
group by fecha
order by fecha



use sac_dic
--Adquirente por dia por cve de transaccion
select 
a.fecha,
b.nombre_banco_grupo,
a.[cve_txn],
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
into #temp_totales
from INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
where fecha>='20221230'
group by a.fecha,
b.nombre_banco_grupo,
a.[cve_txn]

select a.fecha,
a.nombre_banco_grupo,
(select sum(txns) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=101) as ventas_credito_txns,
(select sum(total) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=101) as ventas_credito_total,
(select sum(txns) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=108) as devs_credito_txns,
(select sum(total) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=108) as devs_credito_total,
(select sum(txns) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=103) as ventas_debito_txns,
(select sum(total) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=103) as ventas_debito_total,
(select sum(txns) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=109) as devs_debito_txns,
(select sum(total) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=109) as devs_debito_total,
(select isnull(sum(txns),0) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=106) as cashback_txns,
(select isnull(sum(total),0) from #temp_totales where fecha= a.fecha and nombre_banco_grupo=a.nombre_banco_grupo and cve_txn=106) as cashback_total,
sum(txns) as txns,
sum(total) as total
from #temp_totales as a
group by a.fecha,a.nombre_banco_grupo

--totales por banco

select 
a.nombre_banco_grupo,
sum(total) as total,
sum(txns) as txns
from #temp_totales as a
group by a.nombre_banco_grupo

drop table #temp_totales

--totales
--septiembre
select 
b.nombre_banco_grupo,
sum(a.[IMPORTE]) as total,
sum(a.[cantidad]) as txns
into #temp_totales_totales
from sac.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
group by 
b.nombre_banco_grupo

--octubre
insert into #temp_totales_totales
select 
b.nombre_banco_grupo,
sum(a.[IMPORTE]) as total,
sum(a.[cantidad]) as txns
from sac_oct.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
group by 
b.nombre_banco_grupo

--noviembre
insert into #temp_totales_totales
select 
b.nombre_banco_grupo,
sum(a.[IMPORTE]) as total,
sum(a.[cantidad]) as txns
from sac_nov.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
group by 
b.nombre_banco_grupo

--diciembre
insert into #temp_totales_totales
select 
b.nombre_banco_grupo,
sum(a.[IMPORTE]) as total,
sum(a.[cantidad]) as txns
from sac_dic.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
group by 
b.nombre_banco_grupo

select 
a.nombre_banco_grupo,
sum(total) as total,
sum(txns) as txns
from #temp_totales_totales as a
group by a.nombre_banco_grupo

drop table #temp_totales_totales

--adquirente vs emisor, agregador, afil normal y cleve txn
--insert into bines_emisor
--select left(bin,6) as bin6, INSTITUCION 
--from BOS_DB.dbo.C_BINES_EMISOR
--where INSTITUCION<>'SI VALE FINTECH'
--group by left(bin,6),INSTITUCION
--order by bin6, INSTITUCION

select a.fecha 
,aa.nombre_banco_grupo as id_adquirente
,a.cve_txn
,b.tipo_comercio
,a.cantidad
,a.importe
,case when C.bin6 is null then 
		case when left(a.prefijo,1)='2' then 'MC'
			when left(a.prefijo,1)='5' then 'MC'
			when left(a.prefijo,1)='4' then 'Visa'
		else 'Otros' end
	else c.INSTITUCION end as Emisor
into #temp
from sac_dic.dbo.info_sac as a
inner join sac.dbo.adquirentes as aa on a.id_adquirente =aa.id_adquirente
inner join ACT.[dbo].[ACT] as b on a.[NO_COMERCIO]=b.afiliacion       --se pierden los comercios que aun no est�n en ACT
left join sac.dbo.bines_emisor as C on left(prefijo,6)=C.bin6
where fecha>='20221230'

select fecha,id_adquirente,cve_txn,tipo_comercio,Emisor,--Giro,
sum(cantidad) as txns,
sum(importe) as total
from #temp
group by  fecha,id_adquirente,cve_txn,tipo_comercio,Emisor--,Giro
order by fecha, id_adquirente


drop table #temp



-----SAC VS ACT Afiliaciones transaccionando

select distinct [NO_COMERCIO] 
into #temp_sac
from sac_dic.[dbo].[INFO_SAC] 
where fecha>='20221230'

--create table afil_sac(
--afiliacion varchar(10) null)

--insert into sac.dbo.afil_sac
select * from #temp_sac
where no_comercio not in (select afiliacion from sac.dbo.afil_sac)

--drop table #temp_sac

select a.afiliacion,
	iif(b.afiliacion is null, 'No actualizado',b.Banco) as cve_banco,
	iif(b.afiliacion is null, 'No actualizado',b.tipo_comercio) as tipo_comercio,
	'SI' as transaccionando
		into #temp_sac1
from sac.dbo.afil_sac as A
left join ACT.[dbo].[ACT] as b on a.afiliacion=b.afiliacion


select a.cve_banco,tipo_comercio,transaccionando,count(*) as conteo, 
iif(b.cve_banco is null,'No actualizado',b.institucion) as institucion
into #SALIDA
		from #temp_sac1 as a
left join act.[dbo].[act_bancos] as b on a.cve_banco=b.cve_banco
group by a.cve_banco,tipo_comercio,transaccionando,b.institucion,b.cve_banco


select a.[Afiliacion],a.Banco,a.SIC,a.tipo_comercio,
		'No' as transaccionando
into #temp_act
from 
ACT.[dbo].[ACT] as a
where a.Afiliacion not in (
select afiliacion from sac.dbo.afil_sac)
and [Com Activo]='V'
and banco not in ('BCMR','BNMX')

insert into #SALIDA
select banco,tipo_comercio,transaccionando,count(*) as conteo,
b.institucion
from #temp_act as a
inner join act.[dbo].[act_bancos] as b on a.banco=b.cve_banco
group by a.banco,tipo_comercio,transaccionando,b.institucion--,b.cve_banco


select * from #SALIDA


drop table #temp_sac1
drop table #temp_act
drop table #SALIDA

drop table #temp_sac

--clientes por banco 
--septiembre
select 
b.nombre_banco_grupo,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as cliente,
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
into #temp_clientes
from sac.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join ACT.dbo.[ACT] as c on a.no_comercio=c.afiliacion
group by b.nombre_banco_grupo,c.Afiliacion,c.clasif

--octubre
insert into #temp_clientes
select 
b.nombre_banco_grupo,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as cliente,
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
from sac_oct.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join ACT.dbo.[ACT] as c on a.no_comercio=c.afiliacion
group by b.nombre_banco_grupo,c.Afiliacion,c.clasif

--noviembre
insert into #temp_clientes
select 
b.nombre_banco_grupo,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as cliente,
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
from sac_nov.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join ACT.dbo.[ACT] as c on a.no_comercio=c.afiliacion
group by b.nombre_banco_grupo,c.Afiliacion,c.clasif


--diciembre
insert into #temp_clientes
select 
b.nombre_banco_grupo,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as cliente,
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
from sac_dic.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join ACT.dbo.[ACT] as c on a.no_comercio=c.afiliacion
group by b.nombre_banco_grupo,c.Afiliacion,c.clasif


	select nombre_banco_grupo,
	cliente,
	sum(txns) as txns,
	sum(total) as total
	into #temp_clientes_agrupada
	from #temp_clientes
	group by nombre_banco_grupo,
	cliente
	order by txns desc

select * from #temp_clientes_agrupada
order by txns desc

--top 10 clientes por banco por totales
WITH TOPTEN AS (
    SELECT *, ROW_NUMBER() 
    over (
        PARTITION BY nombre_banco_grupo 
        order by total desc
    ) AS RowNo 
    FROM #temp_clientes_agrupada
)
SELECT * FROM TOPTEN WHERE RowNo <= 10

--top 10 clientes por banco por txns
WITH TOPTEN AS (
    SELECT *, ROW_NUMBER() 
    over (
        PARTITION BY nombre_banco_grupo 
        order by txns desc
    ) AS RowNo 
    FROM #temp_clientes_agrupada
)
SELECT * FROM TOPTEN WHERE RowNo <= 10

declare @total money
declare @txns as decimal(18,2)

select @txns=sum(txns),@total=sum(total) from #temp_clientes_agrupada

--clientes vs prosa txns
select ROW_NUMBER() OVER (ORDER BY sum(txns) desc) as top_txns, 
cliente, 
sum(txns) as txns,
sum(txns)/@txns as perc_txns
from #temp_clientes_agrupada
group by cliente

--clientes vs prosa importe
select ROW_NUMBER() OVER (ORDER BY sum(total) desc) as top_total, 
cliente, 
sum(total) as total,
sum(total)/@total as perc_total
from #temp_clientes_agrupada
group by cliente



drop table #temp_clientes
drop table #temp_clientes_agrupada




--clientes por agregador
--septiembre
select 
b.nombre_banco_grupo,
a.cve_txn,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as agregador,
iif(c.Afiliacion is null,'NO ACTUALIZADA',a.comercio) as comercio,
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
into #temp_clientes_agreg
from sac.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join ACT.[dbo].[ACT] as c on a.no_comercio=c.afiliacion
where c.tipo_comercio='Agregador'
group by b.nombre_banco_grupo,a.cve_txn,c.Afiliacion,c.clasif,a.comercio

--octubre
insert into #temp_clientes_agreg
select 
b.nombre_banco_grupo,
a.cve_txn,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as agregador,
iif(c.Afiliacion is null,'NO ACTUALIZADA',a.comercio) as comercio,
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
from sac_oct.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join ACT.[dbo].[ACT] as c on a.no_comercio=c.afiliacion
where c.tipo_comercio='Agregador'
group by b.nombre_banco_grupo,a.cve_txn,c.Afiliacion,c.clasif,a.comercio


--noviembre
insert into #temp_clientes_agreg
select 
b.nombre_banco_grupo,
a.cve_txn,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as agregador,
iif(c.Afiliacion is null,'NO ACTUALIZADA',a.comercio) as comercio,
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
from SAC_NOV.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join ACT.[dbo].[ACT] as c on a.no_comercio=c.afiliacion
where c.tipo_comercio='Agregador'
group by b.nombre_banco_grupo,a.cve_txn,c.Afiliacion,c.clasif,a.comercio

--DICIEMBRE
insert into #temp_clientes_agreg
select 
b.nombre_banco_grupo,
a.cve_txn,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as agregador,
iif(c.Afiliacion is null,'NO ACTUALIZADA',a.comercio) as comercio,
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
from SAC_DIC.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join ACT.[dbo].[ACT] as c on a.no_comercio=c.afiliacion
where c.tipo_comercio='Agregador'
group by b.nombre_banco_grupo,a.cve_txn,c.Afiliacion,c.clasif,a.comercio

select a.nombre_banco_grupo,
a.agregador,
a.comercio,
sum(a.txns) as txns,
sum(a.total) as total,
(select isnull(sum(txns),0) from #temp_clientes_agreg where nombre_banco_grupo=a.nombre_banco_grupo and agregador=a.agregador and comercio=a.comercio and cve_txn=101) as ventas_credito_txns,
(select isnull(sum(total),0) from #temp_clientes_agreg where nombre_banco_grupo=a.nombre_banco_grupo and agregador=a.agregador and comercio=a.comercio and  cve_txn=101) as ventas_credito_total,
(select isnull(sum(txns),0) from #temp_clientes_agreg where nombre_banco_grupo=a.nombre_banco_grupo and agregador=a.agregador and comercio=a.comercio and  cve_txn=108) as devs_credito_txns,
(select isnull(sum(total),0) from #temp_clientes_agreg where nombre_banco_grupo=a.nombre_banco_grupo and agregador=a.agregador and comercio=a.comercio and  cve_txn=108) as devs_credito_total,
(select isnull(sum(txns),0) from #temp_clientes_agreg where nombre_banco_grupo=a.nombre_banco_grupo and agregador=a.agregador and comercio=a.comercio and  cve_txn=103) as ventas_debito_txns,
(select isnull(sum(total),0) from #temp_clientes_agreg where nombre_banco_grupo=a.nombre_banco_grupo and agregador=a.agregador and comercio=a.comercio and  cve_txn=103) as ventas_debito_total,
(select isnull(sum(txns),0) from #temp_clientes_agreg where nombre_banco_grupo=a.nombre_banco_grupo and agregador=a.agregador and comercio=a.comercio and  cve_txn=109) as devs_debito_txns,
(select isnull(sum(total),0) from #temp_clientes_agreg where nombre_banco_grupo=a.nombre_banco_grupo and agregador=a.agregador and comercio=a.comercio and  cve_txn=109) as devs_debito_total,
(select isnull(sum(txns),0) from #temp_clientes_agreg where nombre_banco_grupo=a.nombre_banco_grupo and agregador=a.agregador and comercio=a.comercio and  cve_txn=106) as cashback_txns,
(select isnull(sum(total),0) from #temp_clientes_agreg where nombre_banco_grupo=a.nombre_banco_grupo and agregador=a.agregador and comercio=a.comercio and cve_txn=106) as cashback_total
into #temp_clientes_agreg_agrupada
from #temp_clientes_agreg as a
group by a.nombre_banco_grupo,a.agregador,a.comercio
order by txns desc

select top 1048576 * from #temp_clientes_agreg_agrupada
order by total desc

drop table #temp_clientes_agreg
drop table #temp_clientes_agreg_agrupada
drop table #temp_sac
----------------------------------------------------------
use sac


--Adquirente por dia por cve de transaccion

select 
b.nombre_banco_grupo as Banco,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as cliente,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.tipo_comercio) as tipo_comercio,
a.no_comercio as afiliacion,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.nombre) as nombre_comercial,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.rfc) as rfc,
a.FECHA,
a.cve_txn,
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
into #temp_final
from INFO_SAC as a
inner join adquirentes as b on a.id_adquirente =b.id_adquirente
left join ACT.[dbo].[ACT] as c on a.no_comercio=c.afiliacion
--where a.fecha<='20220906'
group by b.nombre_banco_grupo,a.cve_txn,c.Afiliacion,c.clasif,a.no_comercio,c.tipo_comercio,c.rfc,c.Nombre,a.fecha


select a.banco,a.cliente, a.tipo_comercio, a.afiliacion, a.nombre_comercial, a.rfc,
--'20220905' AS FECHA,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220905'AND cve_txn=101) AS ventas_credito_txns20220905,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220905' AND cve_txn=101) AS ventas_credito_importe20220905,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220905'AND cve_txn=108) AS devs_credito_txns20220905,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220905' AND cve_txn=108) AS devs_credito_importe20220905,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220905'AND cve_txn=103) AS ventas_debito_txns20220905,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220905' AND cve_txn=103) AS ventas_debito_importe20220905,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220905'AND cve_txn=109) AS devs_debito_txns20220905,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220905' AND cve_txn=109) AS devs_debito_importe20220905,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220905'AND cve_txn=106) AS cashback_txns20220905,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220905' AND cve_txn=106) AS cashback_importe20220905,
--'20220906' AS FECHA,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220906'AND cve_txn=101) AS ventas_credito_txns20220906,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220906' AND cve_txn=101) AS ventas_credito_importe20220906,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220906'AND cve_txn=108) AS devs_credito_txns20220906,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220906' AND cve_txn=108) AS devs_credito_importe20220906,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220906'AND cve_txn=103) AS ventas_debito_txns20220906,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220906' AND cve_txn=103) AS ventas_debito_importe20220906,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220906'AND cve_txn=109) AS devs_debito_txns20220906,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220906' AND cve_txn=109) AS devs_debito_importe20220906,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220906'AND cve_txn=106) AS cashback_txns20220906,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220906' AND cve_txn=106) AS cashback_importe20220906,
--'20220907' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220907'AND cve_txn=101) AS ventas_credito_txns20220907,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220907' AND cve_txn=101) AS ventas_credito_importe20220907,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220907'AND cve_txn=108) AS devs_credito_txns20220907,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220907' AND cve_txn=108) AS devs_credito_importe20220907,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220907'AND cve_txn=103) AS ventas_debito_txns20220907,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220907' AND cve_txn=103) AS ventas_debito_importe20220907,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220907'AND cve_txn=109) AS devs_debito_txns20220907,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220907' AND cve_txn=109) AS devs_debito_importe20220907,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220907'AND cve_txn=106) AS cashback_txns20220907,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220907' AND cve_txn=106) AS cashback_importe20220907,
--'20220908' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220908'AND cve_txn=101) AS ventas_credito_txns20220908,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220908' AND cve_txn=101) AS ventas_credito_importe20220908,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220908'AND cve_txn=108) AS devs_credito_txns20220908,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220908' AND cve_txn=108) AS devs_credito_importe20220908,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220908'AND cve_txn=103) AS ventas_debito_txns20220908,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220908' AND cve_txn=103) AS ventas_debito_importe20220908,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220908'AND cve_txn=109) AS devs_debito_txns20220908,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220908' AND cve_txn=109) AS devs_debito_importe20220908,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220908'AND cve_txn=106) AS cashback_txns20220908,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220908' AND cve_txn=106) AS cashback_importe20220908,
--'20220909' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220909'AND cve_txn=101) AS ventas_credito_txns20220909,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220909' AND cve_txn=101) AS ventas_credito_importe20220909,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220909'AND cve_txn=108) AS devs_credito_txns20220909,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220909' AND cve_txn=108) AS devs_credito_importe20220909,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220909'AND cve_txn=103) AS ventas_debito_txns20220909,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220909' AND cve_txn=103) AS ventas_debito_importe20220909,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220909'AND cve_txn=109) AS devs_debito_txns20220909,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220909' AND cve_txn=109) AS devs_debito_importe20220909,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220909'AND cve_txn=106) AS cashback_txns20220909,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220909' AND cve_txn=106) AS cashback_importe20220909,
--'20220910' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220910'AND cve_txn=101) AS ventas_credito_txns20220910,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220910' AND cve_txn=101) AS ventas_credito_importe20220910,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220910'AND cve_txn=108) AS devs_credito_txns20220910,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220910' AND cve_txn=108) AS devs_credito_importe20220910,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220910'AND cve_txn=103) AS ventas_debito_txns20220910,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220910' AND cve_txn=103) AS ventas_debito_importe20220910,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220910'AND cve_txn=109) AS devs_debito_txns20220910,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220910' AND cve_txn=109) AS devs_debito_importe20220910,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220910'AND cve_txn=106) AS cashback_txns20220910,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220910' AND cve_txn=106) AS cashback_importe20220910,
--'20220911' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220911'AND cve_txn=101) AS ventas_credito_txns20220911,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220911' AND cve_txn=101) AS ventas_credito_importe20220911,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220911'AND cve_txn=108) AS devs_credito_txns20220911,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220911' AND cve_txn=108) AS devs_credito_importe20220911,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220911'AND cve_txn=103) AS ventas_debito_txns20220911,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220911' AND cve_txn=103) AS ventas_debito_importe20220911,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220911'AND cve_txn=109) AS devs_debito_txns20220911,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220911' AND cve_txn=109) AS devs_debito_importe20220911,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220911'AND cve_txn=106) AS cashback_txns20220911,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220911' AND cve_txn=106) AS cashback_importe20220911,
--'20220912' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220912'AND cve_txn=101) AS ventas_credito_txns20220912,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220912' AND cve_txn=101) AS ventas_credito_importe20220912,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220912'AND cve_txn=108) AS devs_credito_txns20220912,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220912' AND cve_txn=108) AS devs_credito_importe20220912,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220912'AND cve_txn=103) AS ventas_debito_txns20220912,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220912' AND cve_txn=103) AS ventas_debito_importe20220912,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220912'AND cve_txn=109) AS devs_debito_txns20220912,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220912' AND cve_txn=109) AS devs_debito_importe20220912,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220912'AND cve_txn=106) AS cashback_txns20220912,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220912' AND cve_txn=106) AS cashback_importe20220912,
--'20220913' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220913'AND cve_txn=101) AS ventas_credito_txns20220913,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220913' AND cve_txn=101) AS ventas_credito_importe20220913,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220913'AND cve_txn=108) AS devs_credito_txns20220913,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220913' AND cve_txn=108) AS devs_credito_importe20220913,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220913'AND cve_txn=103) AS ventas_debito_txns20220913,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220913' AND cve_txn=103) AS ventas_debito_importe20220913,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220913'AND cve_txn=109) AS devs_debito_txns20220913,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220913' AND cve_txn=109) AS devs_debito_importe20220913,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220913'AND cve_txn=106) AS cashback_txns20220913,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220913' AND cve_txn=106) AS cashback_importe20220913,
--'20220914' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220914'AND cve_txn=101) AS ventas_credito_txns20220914,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220914' AND cve_txn=101) AS ventas_credito_importe20220914,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220914'AND cve_txn=108) AS devs_credito_txns20220914,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220914' AND cve_txn=108) AS devs_credito_importe20220914,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220914'AND cve_txn=103) AS ventas_debito_txns20220914,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220914' AND cve_txn=103) AS ventas_debito_importe20220914,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220914'AND cve_txn=109) AS devs_debito_txns20220914,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220914' AND cve_txn=109) AS devs_debito_importe20220914,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220914'AND cve_txn=106) AS cashback_txns20220914,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220914' AND cve_txn=106) AS cashback_importe20220914,
--'20220915' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220915'AND cve_txn=101) AS ventas_credito_txns20220915,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220915' AND cve_txn=101) AS ventas_credito_importe20220915,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220915'AND cve_txn=108) AS devs_credito_txns20220915,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220915' AND cve_txn=108) AS devs_credito_importe20220915,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220915'AND cve_txn=103) AS ventas_debito_txns20220915,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220915' AND cve_txn=103) AS ventas_debito_importe20220915,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220915'AND cve_txn=109) AS devs_debito_txns20220915,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220915' AND cve_txn=109) AS devs_debito_importe20220915,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220915'AND cve_txn=106) AS cashback_txns20220915,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220915' AND cve_txn=106) AS cashback_importe20220915,
--'20220916' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220916'AND cve_txn=101) AS ventas_credito_txns20220916,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220916' AND cve_txn=101) AS ventas_credito_importe20220916,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220916'AND cve_txn=108) AS devs_credito_txns20220916,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220916' AND cve_txn=108) AS devs_credito_importe20220916,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220916'AND cve_txn=103) AS ventas_debito_txns20220916,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220916' AND cve_txn=103) AS ventas_debito_importe20220916,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220916'AND cve_txn=109) AS devs_debito_txns20220916,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220916' AND cve_txn=109) AS devs_debito_importe20220916,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220916'AND cve_txn=106) AS cashback_txns20220916,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220916' AND cve_txn=106) AS cashback_importe20220916,
--'20220917' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220917'AND cve_txn=101) AS ventas_credito_txns20220917,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220917' AND cve_txn=101) AS ventas_credito_importe20220917,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220917'AND cve_txn=108) AS devs_credito_txns20220917,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220917' AND cve_txn=108) AS devs_credito_importe20220917,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220917'AND cve_txn=103) AS ventas_debito_txns20220917,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220917' AND cve_txn=103) AS ventas_debito_importe20220917,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220917'AND cve_txn=109) AS devs_debito_txns20220917,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220917' AND cve_txn=109) AS devs_debito_importe20220917,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220917'AND cve_txn=106) AS cashback_txns20220917,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220917' AND cve_txn=106) AS cashback_importe20220917,
--'20220918' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220918'AND cve_txn=101) AS ventas_credito_txns20220918,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220918' AND cve_txn=101) AS ventas_credito_importe20220918,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220918'AND cve_txn=108) AS devs_credito_txns20220918,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220918' AND cve_txn=108) AS devs_credito_importe20220918,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220918'AND cve_txn=103) AS ventas_debito_txns20220918,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220918' AND cve_txn=103) AS ventas_debito_importe20220918,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220918'AND cve_txn=109) AS devs_debito_txns20220918,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220918' AND cve_txn=109) AS devs_debito_importe20220918,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220918'AND cve_txn=106) AS cashback_txns20220918,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220918' AND cve_txn=106) AS cashback_importe20220918,
--'20220919' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220919'AND cve_txn=101) AS ventas_credito_txns20220919,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220919' AND cve_txn=101) AS ventas_credito_importe20220919,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220919'AND cve_txn=108) AS devs_credito_txns20220919,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220919' AND cve_txn=108) AS devs_credito_importe20220919,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220919'AND cve_txn=103) AS ventas_debito_txns20220919,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220919' AND cve_txn=103) AS ventas_debito_importe20220919,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220919'AND cve_txn=109) AS devs_debito_txns20220919,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220919' AND cve_txn=109) AS devs_debito_importe20220919,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220919'AND cve_txn=106) AS cashback_txns20220919,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220919' AND cve_txn=106) AS cashback_importe20220919,
--'20220920' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220920'AND cve_txn=101) AS ventas_credito_txns20220920,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220920' AND cve_txn=101) AS ventas_credito_importe20220920,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220920'AND cve_txn=108) AS devs_credito_txns20220920,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220920' AND cve_txn=108) AS devs_credito_importe20220920,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220920'AND cve_txn=103) AS ventas_debito_txns20220920,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220920' AND cve_txn=103) AS ventas_debito_importe20220920,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220920'AND cve_txn=109) AS devs_debito_txns20220920,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220920' AND cve_txn=109) AS devs_debito_importe20220920,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220920'AND cve_txn=106) AS cashback_txns20220920,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220920' AND cve_txn=106) AS cashback_importe20220920,
--'20220921' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220921'AND cve_txn=101) AS ventas_credito_txns20220921,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220921' AND cve_txn=101) AS ventas_credito_importe20220921,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220921'AND cve_txn=108) AS devs_credito_txns20220921,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220921' AND cve_txn=108) AS devs_credito_importe20220921,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220921'AND cve_txn=103) AS ventas_debito_txns20220921,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220921' AND cve_txn=103) AS ventas_debito_importe20220921,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220921'AND cve_txn=109) AS devs_debito_txns20220921,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220921' AND cve_txn=109) AS devs_debito_importe20220921,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220921'AND cve_txn=106) AS cashback_txns20220921,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220921' AND cve_txn=106) AS cashback_importe20220921,
--'20220922' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220922'AND cve_txn=101) AS ventas_credito_txns20220922,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220922' AND cve_txn=101) AS ventas_credito_importe20220922,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220922'AND cve_txn=108) AS devs_credito_txns20220922,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220922' AND cve_txn=108) AS devs_credito_importe20220922,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220922'AND cve_txn=103) AS ventas_debito_txns20220922,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220922' AND cve_txn=103) AS ventas_debito_importe20220922,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220922'AND cve_txn=109) AS devs_debito_txns20220922,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220922' AND cve_txn=109) AS devs_debito_importe20220922,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220922'AND cve_txn=106) AS cashback_txns20220922,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220922' AND cve_txn=106) AS cashback_importe20220922,
--'20220923' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220923'AND cve_txn=101) AS ventas_credito_txns20220923,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220923' AND cve_txn=101) AS ventas_credito_importe20220923,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220923'AND cve_txn=108) AS devs_credito_txns20220923,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220923' AND cve_txn=108) AS devs_credito_importe20220923,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220923'AND cve_txn=103) AS ventas_debito_txns20220923,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220923' AND cve_txn=103) AS ventas_debito_importe20220923,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220923'AND cve_txn=109) AS devs_debito_txns20220923,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220923' AND cve_txn=109) AS devs_debito_importe20220923,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220923'AND cve_txn=106) AS cashback_txns20220923,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220923' AND cve_txn=106) AS cashback_importe20220923,
--'20220924' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220924'AND cve_txn=101) AS ventas_credito_txns20220924,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220924' AND cve_txn=101) AS ventas_credito_importe20220924,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220924'AND cve_txn=108) AS devs_credito_txns20220924,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220924' AND cve_txn=108) AS devs_credito_importe20220924,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220924'AND cve_txn=103) AS ventas_debito_txns20220924,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220924' AND cve_txn=103) AS ventas_debito_importe20220924,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220924'AND cve_txn=109) AS devs_debito_txns20220924,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220924' AND cve_txn=109) AS devs_debito_importe20220924,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220924'AND cve_txn=106) AS cashback_txns20220924,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220924' AND cve_txn=106) AS cashback_importe20220924,
--'20220925' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220925'AND cve_txn=101) AS ventas_credito_txns20220925,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220925' AND cve_txn=101) AS ventas_credito_importe20220925,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220925'AND cve_txn=108) AS devs_credito_txns20220925,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220925' AND cve_txn=108) AS devs_credito_importe20220925,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220925'AND cve_txn=103) AS ventas_debito_txns20220925,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220925' AND cve_txn=103) AS ventas_debito_importe20220925,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220925'AND cve_txn=109) AS devs_debito_txns20220925,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220925' AND cve_txn=109) AS devs_debito_importe20220925,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220925'AND cve_txn=106) AS cashback_txns20220925,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220925' AND cve_txn=106) AS cashback_importe20220925,
--'20220926' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220926'AND cve_txn=101) AS ventas_credito_txns20220926,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220926' AND cve_txn=101) AS ventas_credito_importe20220926,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220926'AND cve_txn=108) AS devs_credito_txns20220926,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220926' AND cve_txn=108) AS devs_credito_importe20220926,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220926'AND cve_txn=103) AS ventas_debito_txns20220926,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220926' AND cve_txn=103) AS ventas_debito_importe20220926,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220926'AND cve_txn=109) AS devs_debito_txns20220926,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220926' AND cve_txn=109) AS devs_debito_importe20220926,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220926'AND cve_txn=106) AS cashback_txns20220926,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220926' AND cve_txn=106) AS cashback_importe20220926,
--'20220927' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220927'AND cve_txn=101) AS ventas_credito_txns20220927,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220927' AND cve_txn=101) AS ventas_credito_importe20220927,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220927'AND cve_txn=108) AS devs_credito_txns20220927,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220927' AND cve_txn=108) AS devs_credito_importe20220927,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220927'AND cve_txn=103) AS ventas_debito_txns20220927,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220927' AND cve_txn=103) AS ventas_debito_importe20220927,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220927'AND cve_txn=109) AS devs_debito_txns20220927,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220927' AND cve_txn=109) AS devs_debito_importe20220927,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220927'AND cve_txn=106) AS cashback_txns20220927,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220927' AND cve_txn=106) AS cashback_importe20220927,
--'20220928' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220928'AND cve_txn=101) AS ventas_credito_txns20220928,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220928' AND cve_txn=101) AS ventas_credito_importe20220928,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220928'AND cve_txn=108) AS devs_credito_txns20220928,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220928' AND cve_txn=108) AS devs_credito_importe20220928,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220928'AND cve_txn=103) AS ventas_debito_txns20220928,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220928' AND cve_txn=103) AS ventas_debito_importe20220928,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220928'AND cve_txn=109) AS devs_debito_txns20220928,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220928' AND cve_txn=109) AS devs_debito_importe20220928,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220928'AND cve_txn=106) AS cashback_txns20220928,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220928' AND cve_txn=106) AS cashback_importe20220928,
--'20220929' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220929'AND cve_txn=101) AS ventas_credito_txns20220929,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220929' AND cve_txn=101) AS ventas_credito_importe20220929,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220929'AND cve_txn=108) AS devs_credito_txns20220929,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220929' AND cve_txn=108) AS devs_credito_importe20220929,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220929'AND cve_txn=103) AS ventas_debito_txns20220929,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220929' AND cve_txn=103) AS ventas_debito_importe20220929,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220929'AND cve_txn=109) AS devs_debito_txns20220929,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220929' AND cve_txn=109) AS devs_debito_importe20220929,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220929'AND cve_txn=106) AS cashback_txns20220929,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220929' AND cve_txn=106) AS cashback_importe20220929,
--'20220930' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220930'AND cve_txn=101) AS ventas_credito_txns20220930,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220930' AND cve_txn=101) AS ventas_credito_importe20220930,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220930'AND cve_txn=108) AS devs_credito_txns20220930,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220930' AND cve_txn=108) AS devs_credito_importe20220930,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220930'AND cve_txn=103) AS ventas_debito_txns20220930,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220930' AND cve_txn=103) AS ventas_debito_importe20220930,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220930'AND cve_txn=109) AS devs_debito_txns20220930,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220930' AND cve_txn=109) AS devs_debito_importe20220930,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220930'AND cve_txn=106) AS cashback_txns20220930,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20220930' AND cve_txn=106) AS cashback_importe20220930,
--'20221001' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221001'AND cve_txn=101) AS ventas_credito_txns20221001,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221001' AND cve_txn=101) AS ventas_credito_importe20221001,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221001'AND cve_txn=108) AS devs_credito_txns20221001,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221001' AND cve_txn=108) AS devs_credito_importe20221001,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221001'AND cve_txn=103) AS ventas_debito_txns20221001,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221001' AND cve_txn=103) AS ventas_debito_importe20221001,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221001'AND cve_txn=109) AS devs_debito_txns20221001,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221001' AND cve_txn=109) AS devs_debito_importe20221001,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221001'AND cve_txn=106) AS cashback_txns20221001,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221001' AND cve_txn=106) AS cashback_importe20221001,
--'20221002' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221002'AND cve_txn=101) AS ventas_credito_txns20221002,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221002' AND cve_txn=101) AS ventas_credito_importe20221002,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221002'AND cve_txn=108) AS devs_credito_txns20221002,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221002' AND cve_txn=108) AS devs_credito_importe20221002,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221002'AND cve_txn=103) AS ventas_debito_txns20221002,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221002' AND cve_txn=103) AS ventas_debito_importe20221002,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221002'AND cve_txn=109) AS devs_debito_txns20221002,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221002' AND cve_txn=109) AS devs_debito_importe20221002,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221002'AND cve_txn=106) AS cashback_txns20221002,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221002' AND cve_txn=106) AS cashback_importe20221002,
--'20221003' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221003'AND cve_txn=101) AS ventas_credito_txns20221003,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221003' AND cve_txn=101) AS ventas_credito_importe20221003,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221003'AND cve_txn=108) AS devs_credito_txns20221003,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221003' AND cve_txn=108) AS devs_credito_importe20221003,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221003'AND cve_txn=103) AS ventas_debito_txns20221003,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221003' AND cve_txn=103) AS ventas_debito_importe20221003,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221003'AND cve_txn=109) AS devs_debito_txns20221003,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221003' AND cve_txn=109) AS devs_debito_importe20221003,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221003'AND cve_txn=106) AS cashback_txns20221003,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221003' AND cve_txn=106) AS cashback_importe20221003,
--'20221004' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221004'AND cve_txn=101) AS ventas_credito_txns20221004,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221004' AND cve_txn=101) AS ventas_credito_importe20221004,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221004'AND cve_txn=108) AS devs_credito_txns20221004,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221004' AND cve_txn=108) AS devs_credito_importe20221004,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221004'AND cve_txn=103) AS ventas_debito_txns20221004,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221004' AND cve_txn=103) AS ventas_debito_importe20221004,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221004'AND cve_txn=109) AS devs_debito_txns20221004,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221004' AND cve_txn=109) AS devs_debito_importe20221004,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221004'AND cve_txn=106) AS cashback_txns20221004,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221004' AND cve_txn=106) AS cashback_importe20221004,
--'20221005' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221005'AND cve_txn=101) AS ventas_credito_txns20221005,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221005' AND cve_txn=101) AS ventas_credito_importe20221005,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221005'AND cve_txn=108) AS devs_credito_txns20221005,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221005' AND cve_txn=108) AS devs_credito_importe20221005,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221005'AND cve_txn=103) AS ventas_debito_txns20221005,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221005' AND cve_txn=103) AS ventas_debito_importe20221005,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221005'AND cve_txn=109) AS devs_debito_txns20221005,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221005' AND cve_txn=109) AS devs_debito_importe20221005,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221005'AND cve_txn=106) AS cashback_txns20221005,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221005' AND cve_txn=106) AS cashback_importe20221005,
--'20221006' AS FECHA,
(select isnull(SUM(txns),0)from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221006'AND cve_txn=101) AS ventas_credito_txns20221006,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221006' AND cve_txn=101) AS ventas_credito_importe20221006,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221006'AND cve_txn=108) AS devs_credito_txns20221006,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221006' AND cve_txn=108) AS devs_credito_importe20221006,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221006'AND cve_txn=103) AS ventas_debito_txns20221006,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221006' AND cve_txn=103) AS ventas_debito_importe20221006,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221006'AND cve_txn=109) AS devs_debito_txns20221006,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221006' AND cve_txn=109) AS devs_debito_importe20221006,
(select isnull(SUM(txns),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221006'AND cve_txn=106) AS cashback_txns20221006,
(select isnull(SUM(total),0) from #temp_final where banco=a.banco and afiliacion=a.afiliacion AND FECHA='20221006' AND cve_txn=106) AS cashback_importe20221006,
sum(txns) as total_txns,
sum(total) as total_importe
from #temp_final as a
group by a.banco,a.cliente, a.tipo_comercio, a.afiliacion, a.nombre_comercial, a.rfc

select * from #temp_final


drop table #temp_final

--afiliaciones con dos o m�s adquirentes

select 
b.nombre_banco_grupo as Banco,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as cliente,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.tipo_comercio) as tipo_comercio,
a.no_comercio as afiliacion,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.nombre) as nombre_comercial,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.rfc) as rfc--,
--a.FECHA,
--a.cve_txn,
--sum(a.[cantidad]) as txns,
--sum(a.[IMPORTE]) as total
into #temp_final
from INFO_SAC as a
inner join adquirentes as b on a.id_adquirente =b.id_adquirente
left join [dbo].[ACT] as c on a.no_comercio=c.afiliacion
--where a.fecha<='20220906'
group by b.nombre_banco_grupo,c.Afiliacion,c.clasif,a.no_comercio,c.tipo_comercio,c.rfc,c.Nombre

select * from #temp_final
order by afiliacion


select afiliacion, count(1)
from #temp_final
group by afiliacion
having count(1)>1
--drop table #temp_final






--clientes por banco 
--septiembre
select 
b.nombre_banco_grupo,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as cliente,
c.tipo_comercio,
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
into #temp_clientes
from sac.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join ACT.dbo.[ACT] as c on a.no_comercio=c.afiliacion
group by b.nombre_banco_grupo,c.Afiliacion,c.clasif,c.tipo_comercio

--octubre
insert into #temp_clientes
select 
b.nombre_banco_grupo,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as cliente,
c.tipo_comercio,
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
from sac_oct.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join ACT.dbo.[ACT] as c on a.no_comercio=c.afiliacion
group by b.nombre_banco_grupo,c.Afiliacion,c.clasif,c.tipo_comercio

--noviembre
insert into #temp_clientes
select 
b.nombre_banco_grupo,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as cliente,
c.tipo_comercio,
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
from sac_nov.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join ACT.dbo.[ACT] as c on a.no_comercio=c.afiliacion
group by b.nombre_banco_grupo,c.Afiliacion,c.clasif,c.tipo_comercio


--diciembre
insert into #temp_clientes
select 
b.nombre_banco_grupo,
iif(c.Afiliacion is null,'NO ACTUALIZADA',c.clasif) as cliente,
c.tipo_comercio,
sum(a.[cantidad]) as txns,
sum(a.[IMPORTE]) as total
from sac_dic.dbo.INFO_SAC as a
inner join sac.dbo.adquirentes as b on a.id_adquirente =b.id_adquirente
left join ACT.dbo.[ACT] as c on a.no_comercio=c.afiliacion
group by b.nombre_banco_grupo,c.Afiliacion,c.clasif,c.tipo_comercio


	select nombre_banco_grupo,
	cliente,
	tipo_comercio,
	sum(txns) as txns,
	sum(total) as total
	into #temp_clientes_agrupada
	from #temp_clientes
	group by nombre_banco_grupo,
	cliente,
	tipo_comercio
	order by txns desc

select * from #temp_clientes_agrupada
where nombre_banco_grupo='Banorte'
order by txns desc

--top 10 clientes por banco por totales
WITH TOPTEN AS (
    SELECT *, ROW_NUMBER() 
    over (
        PARTITION BY nombre_banco_grupo 
        order by total desc
    ) AS RowNo 
    FROM #temp_clientes_agrupada
)
SELECT * FROM TOPTEN WHERE RowNo <= 10

--top 10 clientes por banco por txns
WITH TOPTEN AS (
    SELECT *, ROW_NUMBER() 
    over (
        PARTITION BY nombre_banco_grupo 
        order by txns desc
    ) AS RowNo 
    FROM #temp_clientes_agrupada
)
SELECT * FROM TOPTEN WHERE RowNo <= 10

declare @total money
declare @txns as decimal(18,2)

select @txns=sum(txns),@total=sum(total) from #temp_clientes_agrupada

--clientes vs prosa txns
select ROW_NUMBER() OVER (ORDER BY sum(txns) desc) as top_txns, 
cliente, 
sum(txns) as txns,
sum(txns)/@txns as perc_txns
from #temp_clientes_agrupada
group by cliente

--clientes vs prosa importe
select ROW_NUMBER() OVER (ORDER BY sum(total) desc) as top_total, 
cliente, 
sum(total) as total,
sum(total)/@total as perc_total
from #temp_clientes_agrupada
group by cliente



drop table #temp_clientes
drop table #temp_clientes_agrupada



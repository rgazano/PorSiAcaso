using UiPath.CodedWorkflows;

namespace ProyectoDeAutomatizaciónDePrueba
{
    public partial class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{};
        }
    }
}